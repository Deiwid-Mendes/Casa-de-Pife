-- Schema do banco de dados Casa de Pife

CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- Tabela de usuários
CREATE TABLE IF NOT EXISTS users (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    nickname VARCHAR(30) UNIQUE NOT NULL,
    email VARCHAR(255) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    birth_date DATE NOT NULL,
    avatar VARCHAR(50) DEFAULT 'default',
    coins DECIMAL(10, 2) DEFAULT 0.00,
    player_id SERIAL,
    email_verified BOOLEAN DEFAULT FALSE,
    email_token VARCHAR(255),
    is_banned BOOLEAN DEFAULT FALSE,
    self_excluded BOOLEAN DEFAULT FALSE,
    deposit_limit DECIMAL(10, 2) DEFAULT NULL,
    total_games INTEGER DEFAULT 0,
    total_wins INTEGER DEFAULT 0,
    total_losses INTEGER DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Tabela de transações financeiras
CREATE TABLE IF NOT EXISTS transactions (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID REFERENCES users(id) ON DELETE CASCADE,
    type VARCHAR(20) NOT NULL CHECK (type IN ('deposit', 'withdrawal', 'bet', 'win', 'rake', 'refund')),
    amount DECIMAL(10, 2) NOT NULL,
    status VARCHAR(20) DEFAULT 'pending' CHECK (status IN ('pending', 'completed', 'failed', 'cancelled')),
    payment_method VARCHAR(20),
    external_id VARCHAR(255),
    description TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Tabela de histórico de partidas
CREATE TABLE IF NOT EXISTS game_history (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    room_id VARCHAR(20) NOT NULL,
    mode VARCHAR(20) NOT NULL CHECK (mode IN ('free', 'matchmaking', 'private')),
    bet_amount DECIMAL(10, 2) DEFAULT 0,
    pot_amount DECIMAL(10, 2) DEFAULT 0,
    rake_amount DECIMAL(10, 2) DEFAULT 0,
    winner_id UUID REFERENCES users(id),
    players JSONB NOT NULL,
    game_log JSONB,
    duration_seconds INTEGER,
    started_at TIMESTAMP,
    finished_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Tabela de participação em partidas
CREATE TABLE IF NOT EXISTS game_players (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    game_id UUID REFERENCES game_history(id) ON DELETE CASCADE,
    user_id UUID REFERENCES users(id) ON DELETE CASCADE,
    final_hand JSONB,
    is_winner BOOLEAN DEFAULT FALSE,
    coins_change DECIMAL(10, 2) DEFAULT 0,
    penalty_points INTEGER DEFAULT 0
);

-- Índices
CREATE INDEX IF NOT EXISTS idx_users_email ON users(email);
CREATE INDEX IF NOT EXISTS idx_users_nickname ON users(nickname);
CREATE INDEX IF NOT EXISTS idx_transactions_user ON transactions(user_id);
CREATE INDEX IF NOT EXISTS idx_transactions_type ON transactions(type);
CREATE INDEX IF NOT EXISTS idx_game_history_winner ON game_history(winner_id);
CREATE INDEX IF NOT EXISTS idx_game_players_user ON game_players(user_id);