import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';

export default function MatchmakingQueue({ onCancel, position, estimatedWait }) {
  const [elapsed, setElapsed] = useState(0);

  useEffect(() => {
    const timer = setInterval(() => {
      setElapsed(prev => prev + 1);
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center p-4"
    >
      <motion.div
        initial={{ scale: 0.9 }}
        animate={{ scale: 1 }}
        className="bg-felt-900 border border-felt-600 rounded-2xl p-8 max-w-sm w-full text-center"
      >
        <motion.div
          animate={{ rotate: 360 }}
          transition={{ repeat: Infinity, duration: 2, ease: 'linear' }}
          className="text-5xl mb-4 inline-block"
        >
          🔍
        </motion.div>

        <h2 className="text-2xl font-bold text-gold-400 mb-2">Buscando oponente...</h2>

        <div className="text-felt-300 mb-4">
          <motion.div
            animate={{ opacity: [0.3, 1, 0.3] }}
            transition={{ repeat: Infinity, duration: 2 }}
          >
            ● ● ●
          </motion.div>
        </div>

        <div className="bg-felt-800 rounded-xl p-4 mb-6 space-y-2">
          <div className="flex justify-between text-sm">
            <span className="text-felt-400">Tempo de espera:</span>
            <span className="text-white font-mono">{elapsed}s</span>
          </div>
          <div className="flex justify-between text-sm">
            <span className="text-felt-400">Posição na fila:</span>
            <span className="text-white">{position || 1}</span>
          </div>
          <div className="flex justify-between text-sm">
            <span className="text-felt-400">Estimativa:</span>
            <span className="text-white">~{estimatedWait || 15}s</span>
          </div>
        </div>

        <button onClick={onCancel} className="btn-danger w-full">
          ✕ Cancelar Busca
        </button>
      </motion.div>
    </motion.div>
  );
}