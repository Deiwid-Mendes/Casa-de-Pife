import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { useAuth } from '../../contexts/AuthContext';

export default function CreateRoom({ onClose, onCreateRoom }) {
  const { user } = useAuth();
  const [config, setConfig] = useState({
    name: '',
    betAmount: 0,
    maxPlayers: 2,
    maxRounds: 1,
    turnTime: 45,
    password: '',
  });

  const betOptions = [0, 1, 2, 5, 10, 20];
  const playerOptions = [2, 3, 4];

  const handleSubmit = (e) => {
    e.preventDefault();

    if (config.betAmount > 0 && user.coins < config.betAmount) {
      return;
    }

    onCreateRoom(config);
  };

  const rakeAmount = config.betAmount > 0
    ? (config.betAmount * config.maxPlayers * 0.05).toFixed(2)
    : 0;

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center p-4"
    >
      <motion.div
        initial={{ scale: 0.9, y: 20 }}
        animate={{ scale: 1, y: 0 }}
        className="bg-felt-900 border border-felt-600 rounded-2xl p-6 max-w-md w-full"
      >
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-2xl font-bold text-gold-400">🔴 Criar Sala</h2>
          <button onClick={onClose} className="text-felt-400 hover:text-white text-xl">✕</button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          {/* Nome da sala */}
          <div>
            <label className="block text-sm text-felt-300 mb-1">Nome da sala (opcional)</label>
            <input
              type="text"
              value={config.name}
              onChange={(e) => setConfig({ ...config, name: e.target.value })}
              className="input-field"
              placeholder="Ex: Sala do João"
              maxLength={30}
            />
          </div>

          {/* Aposta */}
          <div>
            <label className="block text-sm text-felt-300 mb-2">Valor da aposta</label>
            <div className="grid grid-cols-3 gap-2">
              {betOptions.map(bet => (
                <button
                  key={bet}
                  type="button"
                  onClick={() => setConfig({ ...config, betAmount: bet })}
                  className={`py-2 px-3 rounded-lg text-sm font-bold transition-all ${
                    config.betAmount === bet
                      ? 'bg-gold-500 text-felt-950'
                      : bet > user.coins
                        ? 'bg-felt-800 text-felt-600 cursor-not-allowed'
                        : 'bg-felt-800 text-felt-300 hover:bg-felt-700'
                  }`}
                  disabled={bet > user.coins}
                >
                  {bet === 0 ? '🟢 Grátis' : `🪙 ${bet}`}
                </button>
              ))}
            </div>
          </div>

          {/* Jogadores */}
          <div>
            <label className="block text-sm text-felt-300 mb-2">Número de jogadores</label>
            <div className="flex gap-2">
              {playerOptions.map(num => (
                <button
                  key={num}
                  type="button"
                  onClick={() => setConfig({ ...config, maxPlayers: num })}
                  className={`flex-1 py-2 rounded-lg text-sm font-bold transition-all ${
                    config.maxPlayers === num
                      ? 'bg-gold-500 text-felt-950'
                      : 'bg-felt-800 text-felt-300 hover:bg-felt-700'
                  }`}
                >
                  {num} jogadores
                </button>
              ))}
            </div>
          </div>

          {/* Tempo por turno */}
          <div>
            <label className="block text-sm text-felt-300 mb-2">Tempo por jogada: {config.turnTime}s</label>
            <input
              type="range"
              min="15"
              max="90"
              step="15"
              value={config.turnTime}
              onChange={(e) => setConfig({ ...config, turnTime: parseInt(e.target.value) })}
              className="w-full accent-gold-500"
            />
            <div className="flex justify-between text-xs text-felt-500">
              <span>15s</span>
              <span>45s</span>
              <span>90s</span>
            </div>
          </div>

          {/* Senha */}
          <div>
            <label className="block text-sm text-felt-300 mb-1">Senha da sala</label>
            <input
              type="text"
              value={config.password}
              onChange={(e) => setConfig({ ...config, password: e.target.value })}
              className="input-field"
              placeholder="Senha para entrar"
              required
            />
          </div>

          {/* Info */}
          {config.betAmount > 0 && (
            <div className="bg-felt-800 rounded-xl p-3 text-sm space-y-1">
              <div className="flex justify-between text-felt-300">
                <span>Pote total estimado:</span>
                <span className="text-gold-400 font-bold">{(config.betAmount * config.maxPlayers).toFixed(2)} 🪙</span>
              </div>
              <div className="flex justify-between text-felt-300">
                <span>Rake (5%):</span>
                <span className="text-red-400">{rakeAmount} 🪙</span>
              </div>
              <div className="flex justify-between text-felt-300">
                <span>Prêmio do vencedor:</span>
                <span className="text-emerald-400 font-bold">
                  {(config.betAmount * config.maxPlayers - parseFloat(rakeAmount)).toFixed(2)} 🪙
                </span>
              </div>
            </div>
          )}

          <button type="submit" className="btn-primary w-full text-lg">
            🎮 Criar Sala
          </button>
        </form>
      </motion.div>
    </motion.div>
  );
}