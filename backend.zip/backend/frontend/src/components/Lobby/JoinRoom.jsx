import React, { useState } from 'react';
import { motion } from 'framer-motion';

export default function JoinRoom({ onClose, onJoinRoom }) {
  const [roomId, setRoomId] = useState('');
  const [password, setPassword] = useState('');

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!roomId || !password) return;
    onJoinRoom(roomId.toUpperCase(), password);
  };

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center p-4"
    >
      <motion.div
        initial={{ scale: 0.9, y: 20 }}
        animate={{ scale: 1, y: 0 }}
        className="bg-felt-900 border border-felt-600 rounded-2xl p-6 max-w-md w-full"
      >
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-2xl font-bold text-blue-400">🔵 Entrar na Sala</h2>
          <button onClick={onClose} className="text-felt-400 hover:text-white text-xl">✕</button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-sm text-felt-300 mb-1">ID da Sala</label>
            <input
              type="text"
              value={roomId}
              onChange={(e) => setRoomId(e.target.value.toUpperCase())}
              className="input-field text-center text-xl font-mono tracking-wider"
              placeholder="SALA-0000"
              maxLength={9}
              required
            />
          </div>

          <div>
            <label className="block text-sm text-felt-300 mb-1">Senha</label>
            <input
              type="text"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="input-field"
              placeholder="Senha da sala"
              required
            />
          </div>

          <button type="submit" className="btn-primary w-full text-lg">
            🚪 Entrar
          </button>
        </form>
      </motion.div>
    </motion.div>
  );
}