import React from 'react';
import { motion } from 'framer-motion';

export default function LobbyMain({ user, queueSizes, onFreePlay, onMatchmaking, onCreateRoom, onJoinRoom }) {
  const betOptions = [
    { amount: 1, label: '1 moeda', color: 'from-emerald-600 to-emerald-800' },
    { amount: 2, label: '2 moedas', color: 'from-blue-600 to-blue-800' },
    { amount: 5, label: '5 moedas', color: 'from-purple-600 to-purple-800' },
    { amount: 10, label: '10 moedas', color: 'from-orange-600 to-orange-800' },
    { amount: 20, label: '20 moedas', color: 'from-red-600 to-red-800' },
  ];

  return (
    <div className="max-w-4xl mx-auto px-4 py-8">
      {/* Header */}
      <motion.div
        initial={{ y: -20, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        className="text-center mb-8"
      >
        <h1 className="text-4xl md:text-5xl font-bold mb-2">
          <span className="text-gold-400">🃏 Casa de Pife</span>
        </h1>
        <p className="text-felt-300 text-lg">
          Escolha como quer jogar
        </p>
      </motion.div>

      {/* Main Actions Grid */}
      <div className="grid md:grid-cols-2 gap-6 mb-8">
        {/* Free Play */}
        <motion.button
          initial={{ x: -50, opacity: 0 }}
          animate={{ x: 0, opacity: 1 }}
          transition={{ delay: 0.1 }}
          whileHover={{ scale: 1.02 }}
          whileTap={{ scale: 0.98 }}
          onClick={onFreePlay}
          className="card-container text-left hover:border-emerald-500/50 transition-all group"
        >
          <div className="flex items-start gap-4">
            <div className="text-4xl">🟢</div>
            <div>
              <h3 className="text-xl font-bold text-emerald-400 group-hover:text-emerald-300">
                Jogar Grátis
              </h3>
              <p className="text-felt-400 text-sm mt-1">
                Pratique sem apostar. Sem risco, pura diversão!
              </p>
              <div className="mt-3 text-xs text-felt-500">
                {queueSizes?.[0] || 0} jogador(es) na fila
              </div>
            </div>
          </div>
        </motion.button>

        {/* Create Room */}
        <motion.button
          initial={{ x: 50, opacity: 0 }}
          animate={{ x: 0, opacity: 1 }}
          transition={{ delay: 0.2 }}
          whileHover={{ scale: 1.02 }}
          whileTap={{ scale: 0.98 }}
          onClick={onCreateRoom}
          className="card-container text-left hover:border-red-500/50 transition-all group"
        >
          <div className="flex items-start gap-4">
            <div className="text-4xl">🔴</div>
            <div>
              <h3 className="text-xl font-bold text-red-400 group-hover:text-red-300">
                Criar Sala Privada
              </h3>
              <p className="text-felt-400 text-sm mt-1">
                Crie uma sala com senha e convide seus amigos.
              </p>
              <div className="mt-3 text-xs text-felt-500">
                Configure aposta, jogadores e regras
              </div>
            </div>
          </div>
        </motion.button>
      </div>

      {/* Join Room */}
      <motion.button
        initial={{ y: 20, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ delay: 0.25 }}
        whileHover={{ scale: 1.02 }}
        whileTap={{ scale: 0.98 }}
        onClick={onJoinRoom}
        className="w-full card-container text-left hover:border-blue-500/50 transition-all group mb-8"
      >
        <div className="flex items-center gap-4">
          <div className="text-4xl">🔵</div>
          <div>
            <h3 className="text-xl font-bold text-blue-400 group-hover:text-blue-300">
              Entrar em Sala
            </h3>
            <p className="text-felt-400 text-sm">
              Digite o ID e a senha de uma sala para entrar
            </p>
          </div>
        </div>
      </motion.button>

      {/* Matchmaking with bets */}
      <motion.div
        initial={{ y: 20, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ delay: 0.3 }}
      >
        <h2 className="text-xl font-bold text-gold-400 mb-4 flex items-center gap-2">
          🟡 Jogar Valendo
          <span className="text-sm font-normal text-felt-400">Matchmaking rápido</span>
        </h2>

        <div className="grid grid-cols-2 md:grid-cols-5 gap-3">
          {betOptions.map(({ amount, label, color }) => (
            <motion.button
              key={amount}
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              onClick={() => onMatchmaking(amount)}
              disabled={user.coins < amount}
              className={`
                relative overflow-hidden rounded-xl p-4 text-center
                bg-gradient-to-br ${color}
                ${user.coins < amount ? 'opacity-40 cursor-not-allowed' : 'hover:shadow-lg cursor-pointer'}
                transition-all
              `}
            >
              <div className="text-2xl mb-1">🪙</div>
              <div className="font-bold text-lg">{amount}</div>
              <div className="text-xs opacity-80">{label}</div>
              <div className="text-xs mt-2 opacity-60">
                {queueSizes?.[amount] || 0} na fila
              </div>
            </motion.button>
          ))}
        </div>

        {user.coins < 1 && (
          <p className="text-center text-felt-500 text-sm mt-4">
            💡 Compre moedas na <a href="/store" className="text-gold-400 underline">loja</a> para jogar valendo!
          </p>
        )}
      </motion.div>

      {/* Stats */}
      <motion.div
        initial={{ y: 20, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ delay: 0.4 }}
        className="mt-8 grid grid-cols-3 gap-4"
      >
        <div className="card-container text-center">
          <div className="text-2xl font-bold text-gold-400">{user.totalGames || user.total_games || 0}</div>
          <div className="text-xs text-felt-400">Partidas</div>
        </div>
        <div className="card-container text-center">
          <div className="text-2xl font-bold text-emerald-400">{user.totalWins || user.total_wins || 0}</div>
          <div className="text-xs text-felt-400">Vitórias</div>
        </div>
        <div className="card-container text-center">
          <div className="text-2xl font-bold text-blue-400">
            {(user.totalGames || user.total_games) > 0
              ? (((user.totalWins || user.total_wins || 0) / (user.totalGames || user.total_games)) * 100).toFixed(0)
              : 0}%
          </div>
          <div className="text-xs text-felt-400">Aproveitamento</div>
        </div>
      </motion.div>
    </div>
  );
}