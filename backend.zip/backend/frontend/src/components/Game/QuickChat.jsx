import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';

const EMOJIS = ['👍', '👎', '😂', '😡', '🤔', '😎', '🎉', '💀', '🔥', '❤️', '😢', '🤣'];

export default function QuickChat({ onSendEmoji, chatMessages }) {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <div className="fixed bottom-32 right-4 z-40">
      {/* Chat messages floating */}
      <AnimatePresence>
        {chatMessages.map((msg, i) => (
          <motion.div
            key={msg.id || i}
            initial={{ opacity: 0, y: 20, scale: 0.5 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: -20 }}
            className="mb-2 bg-felt-800/90 rounded-full px-3 py-1 text-sm flex items-center gap-2"
          >
            <span className="text-felt-400 text-xs">{msg.nickname}</span>
            <span className="text-2xl">{msg.emoji}</span>
          </motion.div>
        ))}
      </AnimatePresence>

      {/* Toggle button */}
      <motion.button
        whileTap={{ scale: 0.9 }}
        onClick={() => setIsOpen(!isOpen)}
        className="w-12 h-12 bg-felt-700 hover:bg-felt-600 rounded-full flex items-center justify-center shadow-lg border border-felt-500"
      >
        <span className="text-xl">💬</span>
      </motion.button>

      {/* Emoji picker */}
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, scale: 0.8, y: 10 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.8, y: 10 }}
            className="absolute bottom-14 right-0 bg-felt-800 border border-felt-600 rounded-xl p-3 shadow-2xl grid grid-cols-4 gap-2 w-48"
          >
            {EMOJIS.map(emoji => (
              <motion.button
                key={emoji}
                whileHover={{ scale: 1.2 }}
                whileTap={{ scale: 0.8 }}
                onClick={() => {
                  onSendEmoji(emoji);
                  setIsOpen(false);
                }}
                className="w-10 h-10 flex items-center justify-center rounded-lg hover:bg-felt-700 text-xl transition-colors"
              >
                {emoji}
              </motion.button>
            ))}
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}