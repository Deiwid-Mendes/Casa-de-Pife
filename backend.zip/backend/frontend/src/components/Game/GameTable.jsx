import React from 'react';
import { motion } from 'framer-motion';
import Card from './Card';

export default function GameTable({
  topDiscard,
  deckRemaining,
  onBuyDeck,
  onBuyDiscard,
  canBuy,
  currentPlayerId,
  isMyTurn,
  phase,
}) {
  return (
    <div className="flex items-center justify-center gap-8 md:gap-16 my-8">
      {/* Monte (deck) */}
      <motion.div
        whileHover={canBuy && isMyTurn && phase === 'buy' ? { scale: 1.05 } : {}}
        whileTap={canBuy && isMyTurn && phase === 'buy' ? { scale: 0.95 } : {}}
        onClick={() => canBuy && isMyTurn && phase === 'buy' && onBuyDeck()}
        className={`relative ${canBuy && isMyTurn && phase === 'buy' ? 'cursor-pointer' : 'cursor-default'}`}
      >
        <div className="relative">
          {/* Stack effect */}
          <div className="absolute top-1 left-1 w-20 h-28 bg-blue-950 rounded-lg border-2 border-blue-800"></div>
          <div className="absolute top-0.5 left-0.5 w-20 h-28 bg-blue-900 rounded-lg border-2 border-blue-700"></div>

          <Card faceDown />

          {/* Remaining count */}
          <div className="absolute -bottom-6 left-1/2 -translate-x-1/2 bg-felt-800 px-2 py-0.5 rounded-full text-xs text-felt-300 whitespace-nowrap">
            {deckRemaining} cartas
          </div>
        </div>

        {canBuy && isMyTurn && phase === 'buy' && (
          <motion.div
            animate={{ opacity: [0.5, 1, 0.5] }}
            transition={{ repeat: Infinity, duration: 1.5 }}
            className="absolute -top-8 left-1/2 -translate-x-1/2 bg-emerald-500 text-white text-xs px-2 py-1 rounded-full font-bold whitespace-nowrap"
          >
            Comprar
          </motion.div>
        )}
      </motion.div>

      {/* Separador */}
      <div className="w-px h-32 bg-felt-600/30"></div>

      {/* Lixo (discard pile) */}
      <motion.div
        whileHover={canBuy && isMyTurn && phase === 'buy' && topDiscard ? { scale: 1.05 } : {}}
        whileTap={canBuy && isMyTurn && phase === 'buy' && topDiscard ? { scale: 0.95 } : {}}
        onClick={() => canBuy && isMyTurn && phase === 'buy' && topDiscard && onBuyDiscard()}
        className={`relative ${canBuy && isMyTurn && phase === 'buy' && topDiscard ? 'cursor-pointer' : 'cursor-default'}`}
      >
        {topDiscard ? (
          <>
            <Card card={topDiscard} />
            {canBuy && isMyTurn && phase === 'buy' && (
              <motion.div
                animate={{ opacity: [0.5, 1, 0.5] }}
                transition={{ repeat: Infinity, duration: 1.5 }}
                className="absolute -top-8 left-1/2 -translate-x-1/2 bg-emerald-500 text-white text-xs px-2 py-1 rounded-full font-bold whitespace-nowrap"
              >
                Pegar
              </motion.div>
            )}
          </>
        ) : (
          <div className="w-20 h-28 rounded-lg border-2 border-dashed border-felt-600 flex items-center justify-center">
            <span className="text-felt-600 text-xs text-center">Lixo<br />vazio</span>
          </div>
        )}

        <div className="absolute -bottom-6 left-1/2 -translate-x-1/2 text-xs text-felt-400 whitespace-nowrap">
          Lixo
        </div>
      </motion.div>
    </div>
  );
}