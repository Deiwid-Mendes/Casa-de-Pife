import React from 'react';
import { motion } from 'framer-motion';

const suitSymbols = {
  hearts: '♥',
  diamonds: '♦',
  spades: '♠',
  clubs: '♣',
};

const suitColors = {
  hearts: 'text-red-600',
  diamonds: 'text-red-600',
  spades: 'text-gray-900',
  clubs: 'text-gray-900',
};

export default function Card({
  card,
  faceDown = false,
  selected = false,
  playable = false,
  small = false,
  onClick,
  index = 0,
  draggable = false,
}) {
  const sizeClasses = small
    ? 'w-10 h-14 text-xs'
    : 'w-16 h-24 md:w-20 md:h-28 text-sm md:text-base';

  if (faceDown) {
    return (
      <motion.div
        initial={{ scale: 0, rotateY: 180 }}
        animate={{ scale: 1, rotateY: 0 }}
        transition={{ delay: index * 0.05 }}
        className={`${sizeClasses} rounded-lg shadow-lg select-none flex-shrink-0
          bg-gradient-to-br from-blue-700 via-blue-800 to-blue-950
          border-2 border-blue-600 flex items-center justify-center cursor-default`}
      >
        <div className="w-3/4 h-3/4 border border-blue-500/30 rounded-md flex items-center justify-center">
          <span className="text-2xl opacity-30">🃏</span>
        </div>
      </motion.div>
    );
  }

  if (!card) return null;

  const suit = suitSymbols[card.suit] || '?';
  const color = suitColors[card.suit] || 'text-gray-900';

  return (
    <motion.div
      layout
      initial={{ scale: 0, y: -50 }}
      animate={{
        scale: 1,
        y: selected ? -16 : 0,
      }}
      whileHover={onClick ? { y: -8, scale: 1.05 } : {}}
      whileTap={onClick ? { scale: 0.95 } : {}}
      transition={{ type: 'spring', stiffness: 300, damping: 25, delay: index * 0.03 }}
      onClick={() => onClick && onClick(card)}
      className={`
        ${sizeClasses} rounded-lg shadow-lg select-none flex-shrink-0
        bg-white border-2 flex flex-col items-center justify-between p-1 md:p-1.5
        ${onClick ? 'cursor-pointer' : 'cursor-default'}
        ${selected ? 'ring-4 ring-gold-400 border-gold-500 shadow-gold-400/50 shadow-xl' : 'border-gray-200'}
        ${playable ? 'ring-2 ring-emerald-400 animate-pulse' : ''}
        transition-shadow
      `}
    >
      {/* Top left */}
      <div className={`self-start ${color} font-bold leading-none`}>
        <div className={small ? 'text-[10px]' : 'text-xs md:text-sm'}>{card.value}</div>
        <div className={small ? 'text-[10px]' : 'text-xs md:text-sm'}>{suit}</div>
      </div>

      {/* Center */}
      <div className={`${color} ${small ? 'text-lg' : 'text-2xl md:text-3xl'}`}>
        {suit}
      </div>

      {/* Bottom right */}
      <div className={`self-end ${color} font-bold leading-none rotate-180`}>
        <div className={small ? 'text-[10px]' : 'text-xs md:text-sm'}>{card.value}</div>
        <div className={small ? 'text-[10px]' : 'text-xs md:text-sm'}>{suit}</div>
      </div>
    </motion.div>
  );
}