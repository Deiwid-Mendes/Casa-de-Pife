import React from 'react';
import { motion } from 'framer-motion';
import Card from './Card';

export default function GameResult({ results, userId, onPlayAgain, onBackToLobby }) {
  if (!results) return null;

  const myResult = results.players[userId];
  const isWinner = myResult?.isWinner;
  const isDraw = results.draw;

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4"
    >
      <motion.div
        initial={{ scale: 0.5, y: 50 }}
        animate={{ scale: 1, y: 0 }}
        transition={{ type: 'spring', stiffness: 200 }}
        className="bg-felt-900 border-2 border-felt-600 rounded-3xl p-8 max-w-lg w-full text-center"
      >
        {/* Result Header */}
        {isDraw ? (
          <>
            <motion.div
              animate={{ rotate: [0, 10, -10, 0] }}
              transition={{ repeat: 3, duration: 0.5 }}
              className="text-6xl mb-4"
            >
              🤝
            </motion.div>
            <h2 className="text-3xl font-bold text-gold-400 mb-2">Empate!</h2>
            <p className="text-felt-300">Monte acabou. Apostas devolvidas.</p>
          </>
        ) : isWinner ? (
          <>
            <motion.div
              animate={{ scale: [1, 1.3, 1], rotate: [0, 360] }}
              transition={{ duration: 1 }}
              className="text-6xl mb-4"
            >
              🏆
            </motion.div>
            <h2 className="text-3xl font-bold text-gold-400 mb-2">Vitória!</h2>
            <motion.div
              initial={{ scale: 0 }}
              animate={{ scale: 1 }}
              transition={{ delay: 0.5 }}
              className="text-2xl font-bold text-emerald-400 mb-4"
            >
              +{results.winAmount?.toFixed(2)} 🪙
            </motion.div>
          </>
        ) : (
          <>
            <motion.div
              animate={{ y: [0, 10, 0] }}
              transition={{ repeat: 2, duration: 0.5 }}
              className="text-6xl mb-4"
            >
              😔
            </motion.div>
            <h2 className="text-3xl font-bold text-red-400 mb-2">Derrota</h2>
            <div className="text-xl text-red-300 mb-4">
              -{results.potAmount ? (results.potAmount / Object.keys(results.players).length).toFixed(2) : '0.00'} 🪙
            </div>
          </>
        )}

        {/* Winner's hand */}
        {results.winnerId && results.winnerGroups && (
          <div className="mt-4 mb-6">
            <p className="text-sm text-felt-400 mb-2">Mão vencedora:</p>
            <div className="flex flex-wrap justify-center gap-4">
              {results.winnerGroups.map((group, gi) => (
                <div key={gi} className="flex gap-1 bg-felt-800 rounded-lg p-2">
                  {group.map((card, ci) => (
                    <Card key={ci} card={card} small />
                  ))}
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Stats */}
        <div className="grid grid-cols-2 gap-4 mb-6 text-sm">
          {results.potAmount > 0 && (
            <>
              <div className="bg-felt-800 rounded-xl p-3">
                <div className="text-felt-400">Pote</div>
                <div className="font-bold text-lg">{results.potAmount?.toFixed(2)} 🪙</div>
              </div>
              <div className="bg-felt-800 rounded-xl p-3">
                <div className="text-felt-400">Taxa (rake)</div>
                <div className="font-bold text-lg">{results.rakeAmount?.toFixed(2)} 🪙</div>
              </div>
            </>
          )}
        </div>

        {/* Buttons */}
        <div className="flex gap-3">
          <button onClick={onBackToLobby} className="btn-secondary flex-1">
            🏠 Lobby
          </button>
          <button onClick={onPlayAgain} className="btn-primary flex-1">
            🔄 Jogar Novamente
          </button>
        </div>
      </motion.div>
    </motion.div>
  );
}