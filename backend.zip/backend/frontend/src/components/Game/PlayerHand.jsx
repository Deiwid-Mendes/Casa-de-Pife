import React from 'react';
import { motion } from 'framer-motion';
import Card from './Card';

export default function PlayerHand({ cards, selectedCard, onCardSelect, onCardDiscard, canDiscard }) {
  return (
    <motion.div
      initial={{ y: 100, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      className="fixed bottom-0 left-0 right-0 bg-gradient-to-t from-felt-950 via-felt-950/95 to-transparent pt-8 pb-4 px-2"
    >
      <div className="max-w-2xl mx-auto">
        {/* Action hint */}
        {canDiscard && (
          <motion.p
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="text-center text-gold-400 text-sm mb-2 font-medium"
          >
            {selectedCard ? 'Clique na carta novamente para descartar' : 'Selecione uma carta para descartar'}
          </motion.p>
        )}

        {/* Cards */}
        <div className="flex justify-center gap-1 md:gap-2 flex-wrap">
          {cards.map((card, index) => (
            <Card
              key={card.id}
              card={card}
              index={index}
              selected={selectedCard?.id === card.id}
              onClick={(c) => {
                if (canDiscard) {
                  if (selectedCard?.id === c.id) {
                    onCardDiscard(c);
                  } else {
                    onCardSelect(c);
                  }
                }
              }}
            />
          ))}
        </div>

        {/* Card count */}
        <div className="text-center mt-2 text-felt-400 text-xs">
          {cards.length} cartas na mão
        </div>
      </div>
    </motion.div>
  );
}