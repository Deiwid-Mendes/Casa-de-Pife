import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';

export default function GameTimer({ turnTime, turnStartTime, isMyTurn }) {
  const [timeLeft, setTimeLeft] = useState(turnTime);

  useEffect(() => {
    if (!turnStartTime) return;

    const interval = setInterval(() => {
      const elapsed = Math.floor((Date.now() - turnStartTime) / 1000);
      const remaining = Math.max(0, turnTime - elapsed);
      setTimeLeft(remaining);
    }, 100);

    return () => clearInterval(interval);
  }, [turnStartTime, turnTime]);

  const percentage = (timeLeft / turnTime) * 100;
  const isLow = timeLeft <= 10;

  return (
    <div className="flex flex-col items-center gap-1">
      <div className="relative w-16 h-16">
        <svg className="w-full h-full -rotate-90" viewBox="0 0 36 36">
          {/* Background circle */}
          <path
            d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
            fill="none"
            stroke="#1f4d2e"
            strokeWidth="3"
          />
          {/* Progress circle */}
          <motion.path
            d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
            fill="none"
            stroke={isLow ? '#ef4444' : isMyTurn ? '#fbbf24' : '#6b7280'}
            strokeWidth="3"
            strokeDasharray={`${percentage}, 100`}
            strokeLinecap="round"
          />
        </svg>
        <div className="absolute inset-0 flex items-center justify-center">
          <span className={`text-lg font-bold ${isLow ? 'text-red-400 animate-pulse-fast' : isMyTurn ? 'text-gold-400' : 'text-felt-400'}`}>
            {timeLeft}
          </span>
        </div>
      </div>
      <span className={`text-xs ${isMyTurn ? 'text-gold-400 font-bold' : 'text-felt-500'}`}>
        {isMyTurn ? 'Sua vez!' : 'Aguarde...'}
      </span>
    </div>
  );
}