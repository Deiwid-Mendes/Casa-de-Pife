import React, { useState } from 'react';
import { Link, useNavigate, useLocation } from 'react-router-dom';
import { useAuth } from '../../contexts/AuthContext';
import { motion, AnimatePresence } from 'framer-motion';

const avatarEmojis = {
  default: '😀', cowboy: '🤠', pirate: '🏴‍☠️', ninja: '🥷', astronaut: '👨‍🚀',
  wizard: '🧙', robot: '🤖', alien: '👽', crown: '👑', fire: '🔥',
};

export default function Navbar() {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();
  const [menuOpen, setMenuOpen] = useState(false);

  const handleLogout = () => {
    logout();
    navigate('/');
  };

  const isActive = (path) => location.pathname === path;

  return (
    <nav className="bg-felt-900/90 backdrop-blur-md border-b border-felt-700/50 sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <Link to="/lobby" className="flex items-center gap-2">
            <span className="text-3xl">🃏</span>
            <span className="text-xl font-bold text-gold-400 hidden sm:block">
              Casa de Pife
            </span>
          </Link>

          {/* Nav Links - Desktop */}
          <div className="hidden md:flex items-center gap-1">
            <NavLink to="/lobby" active={isActive('/lobby')}>
              🏠 Lobby
            </NavLink>
            <NavLink to="/store" active={isActive('/store')}>
              🪙 Loja
            </NavLink>
            <NavLink to="/history" active={isActive('/history')}>
              📊 Histórico
            </NavLink>
            <NavLink to="/profile" active={isActive('/profile')}>
              👤 Perfil
            </NavLink>
          </div>

          {/* Right side */}
          <div className="flex items-center gap-4">
            {/* Saldo */}
            <Link to="/store" className="flex items-center gap-2 bg-felt-800 rounded-full px-4 py-2 border border-gold-600/30 hover:border-gold-500/50 transition-all">
              <span className="text-xl">🪙</span>
              <span className="font-bold text-gold-400">
                {user?.coins?.toFixed(2) || '0.00'}
              </span>
            </Link>

            {/* Avatar & Menu */}
            <div className="relative">
              <button
                onClick={() => setMenuOpen(!menuOpen)}
                className="flex items-center gap-2 bg-felt-800 rounded-full px-3 py-2 hover:bg-felt-700 transition-all"
              >
                <span className="text-xl">{avatarEmojis[user?.avatar] || '😀'}</span>
                <span className="hidden sm:block text-sm font-medium">{user?.nickname}</span>
                <svg className={`w-4 h-4 transition-transform ${menuOpen ? 'rotate-180' : ''}`} fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
                </svg>
              </button>

              <AnimatePresence>
                {menuOpen && (
                  <motion.div
                    initial={{ opacity: 0, y: -10 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -10 }}
                    className="absolute right-0 mt-2 w-48 bg-felt-800 border border-felt-600 rounded-xl shadow-2xl overflow-hidden z-50"
                  >
                    <div className="px-4 py-3 border-b border-felt-700">
                      <p className="text-sm font-bold">{user?.nickname}</p>
                      <p className="text-xs text-felt-400">#{user?.player_id || user?.playerId}</p>
                    </div>

                    <div className="md:hidden">
                      <MenuLink to="/lobby" onClick={() => setMenuOpen(false)}>🏠 Lobby</MenuLink>
                      <MenuLink to="/store" onClick={() => setMenuOpen(false)}>🪙 Loja</MenuLink>
                      <MenuLink to="/history" onClick={() => setMenuOpen(false)}>📊 Histórico</MenuLink>
                    </div>

                    <MenuLink to="/profile" onClick={() => setMenuOpen(false)}>👤 Perfil</MenuLink>

                    <button
                      onClick={() => { handleLogout(); setMenuOpen(false); }}
                      className="w-full text-left px-4 py-2 text-sm text-red-400 hover:bg-felt-700 transition-colors"
                    >
                      🚪 Sair
                    </button>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          </div>
        </div>
      </div>
    </nav>
  );
}

function NavLink({ to, active, children }) {
  return (
    <Link
      to={to}
      className={`px-4 py-2 rounded-lg text-sm font-medium transition-all ${
        active
          ? 'bg-gold-500/20 text-gold-400 border border-gold-500/30'
          : 'text-felt-300 hover:text-white hover:bg-felt-800'
      }`}
    >
      {children}
    </Link>
  );
}

function MenuLink({ to, onClick, children }) {
  return (
    <Link
      to={to}
      onClick={onClick}
      className="block px-4 py-2 text-sm text-felt-200 hover:bg-felt-700 transition-colors"
    >
      {children}
    </Link>
  );
}