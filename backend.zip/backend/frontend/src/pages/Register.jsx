import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { useAuth } from '../contexts/AuthContext';
import toast from 'react-hot-toast';

export default function Register() {
  const [form, setForm] = useState({
    nickname: '',
    email: '',
    password: '',
    confirmPassword: '',
    birthDate: '',
    acceptTerms: false,
  });
  const [loading, setLoading] = useState(false);
  const { register } = useAuth();
  const navigate = useNavigate();

  const handleChange = (e) => {
    const { name, value, type, checked } = e.target;
    setForm(prev => ({
      ...prev,
      [name]: type === 'checkbox' ? checked : value,
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (form.password !== form.confirmPassword) {
      return toast.error('As senhas não coincidem');
    }

    if (!form.acceptTerms) {
      return toast.error('Você precisa aceitar os termos de uso');
    }

    setLoading(true);

    try {
      await register(form.nickname, form.email, form.password, form.birthDate);
      toast.success('Conta criada com sucesso! 🎉');
      navigate('/lobby');
    } catch (error) {
      const msg = error.response?.data?.error || error.response?.data?.errors?.[0] || 'Erro no cadastro';
      toast.error(msg);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center px-4 py-12">
      <motion.div
        initial={{ y: 20, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        className="card-container max-w-md w-full"
      >
        <div className="text-center mb-8">
          <Link to="/" className="text-4xl inline-block mb-2">🃏</Link>
          <h1 className="text-3xl font-bold text-gold-400">Criar Conta</h1>
          <p className="text-felt-400 mt-1">Entre para a Casa de Pife</p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-sm text-felt-300 mb-1">Nickname</label>
            <input
              type="text"
              name="nickname"
              value={form.nickname}
              onChange={handleChange}
              className="input-field"
              placeholder="SeuNickname"
              minLength={3}
              maxLength={20}
              pattern="[a-zA-Z0-9_]+"
              title="Apenas letras, números e underscore"
              required
            />
          </div>

          <div>
            <label className="block text-sm text-felt-300 mb-1">E-mail</label>
            <input
              type="email"
              name="email"
              value={form.email}
              onChange={handleChange}
              className="input-field"
              placeholder="seu@email.com"
              required
            />
          </div>

          <div>
            <label className="block text-sm text-felt-300 mb-1">Data de Nascimento</label>
            <input
              type="date"
              name="birthDate"
              value={form.birthDate}
              onChange={handleChange}
              className="input-field"
              required
            />
            <p className="text-xs text-felt-500 mt-1">🔞 Você deve ter 18 anos ou mais</p>
          </div>

          <div>
            <label className="block text-sm text-felt-300 mb-1">Senha</label>
            <input
              type="password"
              name="password"
              value={form.password}
              onChange={handleChange}
              className="input-field"
              placeholder="Mínimo 6 caracteres"
              minLength={6}
              required
            />
          </div>

          <div>
            <label className="block text-sm text-felt-300 mb-1">Confirmar Senha</label>
            <input
              type="password"
              name="confirmPassword"
              value={form.confirmPassword}
              onChange={handleChange}
              className="input-field"
              placeholder="Repita a senha"
              required
            />
          </div>

          <label className="flex items-start gap-3 cursor-pointer">
            <input
              type="checkbox"
              name="acceptTerms"
              checked={form.acceptTerms}
              onChange={handleChange}
              className="mt-1 w-4 h-4 accent-gold-500"
            />
            <span className="text-sm text-felt-400">
              Li e aceito os <span className="text-gold-400">Termos de Uso</span>,{' '}
              <span className="text-gold-400">Política de Privacidade</span> e{' '}
              <span className="text-gold-400">Política de Jogo Responsável</span>.
            </span>
          </label>

          <button type="submit" disabled={loading} className="btn-primary w-full text-lg">
            {loading ? (
              <span className="flex items-center justify-center gap-2">
                <svg className="animate-spin h-5 w-5" viewBox="0 0 24 24">
                  <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" fill="none" />
                  <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z" />
                </svg>
                Criando conta...
              </span>
            ) : '🚀 Criar Conta'}
          </button>
        </form>

        <div className="mt-6 text-center">
          <p className="text-felt-400 text-sm">
            Já tem conta?{' '}
            <Link to="/login" className="text-gold-400 hover:text-gold-300 font-medium">
              Fazer login
            </Link>
          </p>
        </div>
      </motion.div>
    </div>
  );
}