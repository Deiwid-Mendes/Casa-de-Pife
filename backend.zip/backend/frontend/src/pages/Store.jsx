import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { useAuth } from '../contexts/AuthContext';
import toast from 'react-hot-toast';

const PACKAGES = [
  { id: 'basic', name: 'Básico', price: 5, coins: 5, icon: '🟤', popular: false },
  { id: 'bronze', name: 'Bronze', price: 10, coins: 10, icon: '🥉', popular: false },
  { id: 'silver', name: 'Prata', price: 20, coins: 20, icon: '🥈', popular: true },
  { id: 'gold', name: 'Ouro', price: 30, coins: 30, icon: '🥇', popular: false },
  { id: 'diamond', name: 'Diamante', price: 50, coins: 50, icon: '💎', popular: false },
];

export default function Store() {
  const { user, api, refreshUser } = useAuth();
  const [loading, setLoading] = useState(null);
  const [showWithdraw, setShowWithdraw] = useState(false);
  const [withdrawAmount, setWithdrawAmount] = useState('');
  const [pixKey, setPixKey] = useState('');

  const handleBuy = async (packageId) => {
    setLoading(packageId);
    try {
      const { data } = await api.post('/payment/deposit', {
        packageId,
        paymentMethod: 'pix',
      });
      toast.success(data.message);
      await refreshUser();
    } catch (error) {
      toast.error(error.response?.data?.error || 'Erro ao processar pagamento');
    } finally {
      setLoading(null);
    }
  };

  const handleWithdraw = async (e) => {
    e.preventDefault();
    const amount = parseFloat(withdrawAmount);
    if (isNaN(amount) || amount < 10) {
      return toast.error('Saque mínimo: 10 moedas');
    }

    try {
      const { data } = await api.post('/payment/withdraw', {
        amount,
        pixKey,
      });
      toast.success(data.message);
      await refreshUser();
      setShowWithdraw(false);
      setWithdrawAmount('');
      setPixKey('');
    } catch (error) {
      toast.error(error.response?.data?.error || 'Erro ao processar saque');
    }
  };

  return (
    <div className="max-w-4xl mx-auto px-4 py-8">
      <motion.div initial={{ y: 20, opacity: 0 }} animate={{ y: 0, opacity: 1 }}>
        {/* Header */}
        <div className="text-center mb-8">
          <h1 className="text-3xl font-bold text-gold-400">🪙 Loja de Moedas</h1>
          <p className="text-felt-300 mt-1">1 moeda = R$ 1,00</p>

          <div className="inline-flex items-center gap-2 bg-felt-800 rounded-full px-6 py-3 mt-4">
            <span className="text-felt-400">Seu saldo:</span>
            <span className="text-2xl font-bold text-gold-400">
              🪙 {(user?.coins || 0).toFixed(2)}
            </span>
          </div>
        </div>

        {/* Packages */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4 mb-8">
          {PACKAGES.map((pkg, index) => (
            <motion.div
              key={pkg.id}
              initial={{ y: 30, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              transition={{ delay: index * 0.1 }}
              className={`card-container relative text-center ${
                pkg.popular ? 'border-gold-500 ring-2 ring-gold-500/30' : ''
              }`}
            >
              {pkg.popular && (
                <div className="absolute -top-3 left-1/2 -translate-x-1/2 bg-gold-500 text-felt-950 px-3 py-0.5 rounded-full text-xs font-bold">
                  POPULAR
                </div>
              )}

              <div className="text-4xl mb-2">{pkg.icon}</div>
              <h3 className="text-lg font-bold text-white">{pkg.name}</h3>

              <div className="my-3">
                <div className="text-3xl font-bold text-gold-400">{pkg.coins}</div>
                <div className="text-sm text-felt-400">moedas</div>
              </div>

              <div className="text-lg font-bold text-emerald-400 mb-3">
                R$ {pkg.price.toFixed(2)}
              </div>

              <button
                onClick={() => handleBuy(pkg.id)}
                disabled={loading === pkg.id}
                className="btn-primary w-full text-sm"
              >
                {loading === pkg.id ? (
                  <span className="animate-spin inline-block">⏳</span>
                ) : (
                  '💳 Comprar via PIX'
                )}
              </button>
            </motion.div>
          ))}
        </div>

        {/* Payment methods info */}
        <div className="card-container mb-6">
          <h3 className="text-lg font-bold text-gold-400 mb-3">Métodos de Pagamento</h3>
          <div className="grid grid-cols-3 gap-4 text-center">
            <div className="bg-felt-800 rounded-xl p-3">
              <div className="text-2xl mb-1">⚡</div>
              <div className="text-sm font-medium">PIX</div>
              <div className="text-xs text-felt-400">Instantâneo</div>
            </div>
            <div className="bg-felt-800 rounded-xl p-3">
              <div className="text-2xl mb-1">💳</div>
              <div className="text-sm font-medium">Cartão</div>
              <div className="text-xs text-felt-400">Crédito/Débito</div>
            </div>
            <div className="bg-felt-800 rounded-xl p-3">
              <div className="text-2xl mb-1">📄</div>
              <div className="text-sm font-medium">Boleto</div>
              <div className="text-xs text-felt-400">Até 2 dias</div>
            </div>
          </div>
        </div>

        {/* Withdraw */}
        <div className="card-container">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-bold text-gold-400">💸 Saque</h3>
            <button
              onClick={() => setShowWithdraw(!showWithdraw)}
              className="btn-secondary text-sm"
            >
              {showWithdraw ? 'Cancelar' : 'Solicitar Saque'}
            </button>
          </div>

          {showWithdraw ? (
            <form onSubmit={handleWithdraw} className="space-y-4">
              <div>
                <label className="block text-sm text-felt-300 mb-1">
                  Valor (mínimo 10 moedas)
                </label>
                <input
                  type="number"
                  value={withdrawAmount}
                  onChange={(e) => setWithdrawAmount(e.target.value)}
                  className="input-field"
                  placeholder="10"
                  min="10"
                  max={user?.coins || 0}
                  step="0.01"
                  required
                />
              </div>

              <div>
                <label className="block text-sm text-felt-300 mb-1">Chave PIX</label>
                <input
                  type="text"
                  value={pixKey}
                  onChange={(e) => setPixKey(e.target.value)}
                  className="input-field"
                  placeholder="CPF, e-mail, telefone ou chave aleatória"
                  required
                />
              </div>

              {withdrawAmount && parseFloat(withdrawAmount) >= 10 && (
                <div className="bg-felt-800 rounded-xl p-3 text-sm space-y-1">
                  <div className="flex justify-between">
                    <span className="text-felt-400">Valor:</span>
                    <span>R$ {parseFloat(withdrawAmount).toFixed(2)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-felt-400">Taxa (2%):</span>
                    <span className="text-red-400">
                      -R$ {(parseFloat(withdrawAmount) * 0.02).toFixed(2)}
                    </span>
                  </div>
                  <div className="flex justify-between font-bold border-t border-felt-700 pt-1">
                    <span>Você recebe:</span>
                    <span className="text-emerald-400">
                      R$ {(parseFloat(withdrawAmount) * 0.98).toFixed(2)}
                    </span>
                  </div>
                </div>
              )}

              <button type="submit" className="btn-success w-full">
                Confirmar Saque
              </button>
            </form>
          ) : (
            <div className="text-sm text-felt-400 space-y-1">
              <p>• Saque mínimo: 10 moedas (R$ 10,00)</p>
              <p>• Taxa: 2% do valor</p>
              <p>• Processamento: até 24h úteis via PIX</p>
            </div>
          )}
        </div>
      </motion.div>
    </div>
  );
}