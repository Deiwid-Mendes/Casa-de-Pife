import React, { useState, useEffect, useCallback, useRef } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { useAuth } from '../contexts/AuthContext';
import { useSocket } from '../contexts/SocketContext';
import GameTable from '../components/Game/GameTable';
import PlayerHand from '../components/Game/PlayerHand';
import OpponentHand from '../components/Game/OpponentHand';
import GameTimer from '../components/Game/GameTimer';
import GameResult from '../components/Game/GameResult';
import QuickChat from '../components/Game/QuickChat';
import toast from 'react-hot-toast';

export default function Game() {
  const { roomId } = useParams();
  const { user } = useAuth();
  const { socket } = useSocket();
  const navigate = useNavigate();

  const [gameState, setGameState] = useState(null);
  const [selectedCard, setSelectedCard] = useState(null);
  const [canBat, setCanBat] = useState(false);
  const [canIntercept, setCanIntercept] = useState(false);
  const [interceptCard, setInterceptCard] = useState(null);
  const [results, setResults] = useState(null);
  const [chatMessages, setChatMessages] = useState([]);
  const [waitingRoom, setWaitingRoom] = useState(true);
  const [playersReady, setPlayersReady] = useState({});

  const chatTimeoutRef = useRef(null);

  useEffect(() => {
    if (!socket) return;

    // Game state updates
    socket.on('game:state', (state) => {
      setGameState(state);
      setWaitingRoom(false);
    });

    socket.on('game:started', (state) => {
      setGameState(state);
      setWaitingRoom(false);
      toast.success('Partida começou! 🃏');
    });

    // Card actions
    socket.on('game:card_bought', ({ card, canBat: canBatNow }) => {
      setCanBat(canBatNow);
      if (canBatNow) {
        toast.success('Você pode BATER! 🏆', { icon: '🎉', duration: 5000 });
      }
    });

    socket.on('game:opponent_bought', ({ userId, source }) => {
      // Update will come via game:state
    });

    socket.on('game:card_discarded', ({ userId, card }) => {
      setSelectedCard(null);
      setCanBat(false);
    });

    socket.on('game:can_intercept', ({ card, timeout }) => {
      setCanIntercept(true);
      setInterceptCard(card);
      toast('Você pode BATER com essa carta! 🔥', { icon: '⚡', duration: timeout });

      if (chatTimeoutRef.current) clearTimeout(chatTimeoutRef.current);
      chatTimeoutRef.current = setTimeout(() => {
        setCanIntercept(false);
        setInterceptCard(null);
      }, timeout);
    });

    socket.on('game:auto_play', ({ userId }) => {
      if (userId === user.id) {
        toast('Tempo esgotado! Jogada automática.', { icon: '⏰' });
      }
    });

    // Game end
    socket.on('game:ended', (gameResults) => {
      setResults(gameResults);
    });

    // Room events
    socket.on('room:player_joined', ({ player }) => {
      toast(`${player.nickname} entrou na sala!`, { icon: '👋' });
    });

    socket.on('room:player_ready', ({ userId }) => {
      setPlayersReady(prev => ({ ...prev, [userId]: true }));
    });

    socket.on('room:player_disconnected', ({ userId }) => {
      toast('Um jogador desconectou...', { icon: '⚠️' });
    });

    socket.on('room:player_reconnected', ({ userId }) => {
      toast('Jogador reconectou!', { icon: '✅' });
    });

    // Chat
    socket.on('chat:emoji', ({ userId, nickname, emoji }) => {
      setChatMessages(prev => [
        ...prev.slice(-4),
        { id: Date.now(), userId, nickname, emoji },
      ]);

      // Auto remove after 3s
      setTimeout(() => {
        setChatMessages(prev => prev.filter(m => m.id !== Date.now()));
      }, 3000);
    });

    // Reconnect if coming from lobby
    socket.emit('game:reconnect');

    return () => {
      socket.off('game:state');
      socket.off('game:started');
      socket.off('game:card_bought');
      socket.off('game:opponent_bought');
      socket.off('game:card_discarded');
      socket.off('game:can_intercept');
      socket.off('game:auto_play');
      socket.off('game:ended');
      socket.off('room:player_joined');
      socket.off('room:player_ready');
      socket.off('room:player_disconnected');
      socket.off('room:player_reconnected');
      socket.off('chat:emoji');
    };
  }, [socket, user]);

  const handleReady = useCallback(() => {
    if (socket) {
      socket.emit('room:ready');
      setPlayersReady(prev => ({ ...prev, [user.id]: true }));
    }
  }, [socket, user]);

  const handleBuyDeck = useCallback(() => {
    if (socket) socket.emit('game:buy_deck');
  }, [socket]);

  const handleBuyDiscard = useCallback(() => {
    if (socket) socket.emit('game:buy_discard');
  }, [socket]);

  const handleDiscard = useCallback((card) => {
    if (socket) {
      socket.emit('game:discard', { cardId: card.id });
      setSelectedCard(null);
    }
  }, [socket]);

  const handleBat = useCallback(() => {
    if (socket) socket.emit('game:bat');
  }, [socket]);

  const handleInterceptBat = useCallback(() => {
    if (socket) {
      socket.emit('game:intercept_bat');
      setCanIntercept(false);
    }
  }, [socket]);

  const handleSendEmoji = useCallback((emoji) => {
    if (socket) socket.emit('chat:emoji', { emoji });
  }, [socket]);

  const handlePlayAgain = useCallback(() => {
    setResults(null);
    setGameState(null);
    setWaitingRoom(true);
    setCanBat(false);
    setSelectedCard(null);
    if (socket) socket.emit('room:ready');
  }, [socket]);

  const handleBackToLobby = useCallback(() => {
    navigate('/lobby');
  }, [navigate]);

  // ---- RENDER ----

  const isMyTurn = gameState?.currentPlayerId === user?.id;
  const myHand = gameState?.players?.[user?.id]?.hand || [];
  const opponents = gameState ? Object.entries(gameState.players).filter(([id]) => id !== user?.id) : [];
  const myPlayerData = gameState?.players?.[user?.id];

  // Waiting Room
  if (waitingRoom || !gameState || gameState.state === 'waiting') {
    return (
      <div className="min-h-screen flex items-center justify-center px-4">
        <motion.div
          initial={{ scale: 0.9, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          className="card-container max-w-md w-full text-center"
        >
          <h2 className="text-2xl font-bold text-gold-400 mb-4">🏠 Sala de Espera</h2>

          <div className="bg-felt-800 rounded-xl p-4 mb-6">
            <p className="text-sm text-felt-400 mb-1">ID da Sala</p>
            <p className="text-2xl font-mono font-bold text-white">{roomId}</p>
          </div>

          {gameState && (
            <div className="space-y-3 mb-6">
              <p className="text-felt-300">
                Jogadores: {Object.keys(gameState.players || {}).length}/{gameState.maxPlayers || 2}
              </p>

              {Object.values(gameState.players || {}).map(player => (
                <div key={player.id} className="flex items-center justify-between bg-felt-800 rounded-lg px-4 py-2">
                  <div className="flex items-center gap-2">
                    <span>{player.id === user?.id ? '👤' : '🎭'}</span>
                    <span>{player.nickname}</span>
                  </div>
                  <span className={`text-sm ${playersReady[player.id] || player.ready ? 'text-emerald-400' : 'text-felt-500'}`}>
                    {playersReady[player.id] || player.ready ? '✅ Pronto' : '⏳ Aguardando'}
                  </span>
                </div>
              ))}
            </div>
          )}

          {!(playersReady[user?.id]) && (
            <button onClick={handleReady} className="btn-success w-full text-lg">
              ✅ Estou Pronto!
            </button>
          )}

          {playersReady[user?.id] && (
            <p className="text-emerald-400 animate-pulse">
              Aguardando outros jogadores ficarem prontos...
            </p>
          )}

          <button onClick={handleBackToLobby} className="btn-secondary w-full mt-4">
            ← Voltar ao Lobby
          </button>
        </motion.div>
      </div>
    );
  }

  // Game Screen
  return (
    <div className="min-h-screen relative overflow-hidden">
      {/* Game info bar */}
      <div className="bg-felt-900/90 backdrop-blur-sm border-b border-felt-700/50 px-4 py-2 flex items-center justify-between">
        <div className="flex items-center gap-4">
          <button onClick={handleBackToLobby} className="text-felt-400 hover:text-white text-sm">
            ← Sair
          </button>
          <span className="text-felt-500 text-sm hidden sm:block">{roomId}</span>
        </div>

        <GameTimer
          turnTime={gameState?.turnTime || 45}
          turnStartTime={gameState?.turnStartTime}
          isMyTurn={isMyTurn}
        />

        <div className="flex items-center gap-2">
          {gameState?.betAmount > 0 && (
            <span className="bg-gold-500/20 text-gold-400 px-3 py-1 rounded-full text-sm font-bold">
              🪙 {gameState.betAmount}/jogador
            </span>
          )}
        </div>
      </div>

      {/* Game table */}
      <div className="felt-table mx-4 md:mx-auto max-w-3xl mt-4 p-6 md:p-8 relative min-h-[60vh]">
        {/* Opponents */}
        {opponents.map(([id, player], index) => {
          const positions = ['top', 'left', 'right'];
          return (
            <OpponentHand
              key={id}
              player={player}
              isCurrentTurn={gameState?.currentPlayerId === id}
              position={positions[index] || 'top'}
            />
          );
        })}

        {/* Center: Deck & Discard */}
        <div className="flex items-center justify-center min-h-[200px]">
          <GameTable
            topDiscard={gameState?.discardPile}
            deckRemaining={gameState?.deckRemaining}
            onBuyDeck={handleBuyDeck}
            onBuyDiscard={handleBuyDiscard}
            canBuy={isMyTurn}
            isMyTurn={isMyTurn}
            phase={gameState?.phase}
          />
        </div>

        {/* Pifado indicator */}
        {myPlayerData?.isPifado && (
          <motion.div
            animate={{ scale: [1, 1.1, 1] }}
            transition={{ repeat: Infinity, duration: 1 }}
            className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 bg-red-600 text-white px-6 py-2 rounded-full font-bold text-lg shadow-2xl pointer-events-none"
          >
            🔥 PIFADO!
          </motion.div>
        )}

        {/* Turn indicator */}
        <div className="absolute bottom-2 left-1/2 -translate-x-1/2">
          <span className={`text-sm font-medium px-4 py-1 rounded-full ${
            isMyTurn ? 'bg-gold-500/20 text-gold-400 animate-pulse' : 'bg-felt-800 text-felt-500'
          }`}>
            {isMyTurn
              ? (gameState?.phase === 'buy' ? '🃏 Compre uma carta' : '🗑️ Descarte uma carta')
              : `Vez de ${opponents.find(([id]) => id === gameState?.currentPlayerId)?.[1]?.nickname || '...'}`
            }
          </span>
        </div>
      </div>

      {/* BAT button */}
      <AnimatePresence>
        {canBat && isMyTurn && (
          <motion.button
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            exit={{ scale: 0 }}
            whileTap={{ scale: 0.9 }}
            onClick={handleBat}
            className="fixed top-1/2 right-4 -translate-y-1/2 bg-gradient-to-r from-gold-500 to-gold-600 text-felt-950 px-8 py-4 rounded-2xl font-bold text-xl shadow-2xl animate-glow z-40"
          >
            🏆 BATER!
          </motion.button>
        )}

        {canIntercept && (
          <motion.button
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            exit={{ scale: 0 }}
            whileTap={{ scale: 0.9 }}
            onClick={handleInterceptBat}
            className="fixed top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 bg-gradient-to-r from-red-500 to-red-600 text-white px-8 py-4 rounded-2xl font-bold text-xl shadow-2xl animate-glow z-40"
          >
            ⚡ BATER COM LIXO!
          </motion.button>
        )}
      </AnimatePresence>

      {/* Player hand */}
      <PlayerHand
        cards={myHand}
        selectedCard={selectedCard}
        onCardSelect={setSelectedCard}
        onCardDiscard={handleDiscard}
        canDiscard={isMyTurn && gameState?.phase === 'discard'}
      />

      {/* Quick chat */}
      <QuickChat
        onSendEmoji={handleSendEmoji}
        chatMessages={chatMessages}
      />

      {/* Results modal */}
      <AnimatePresence>
        {results && (
          <GameResult
            results={results}
            userId={user?.id}
            onPlayAgain={handlePlayAgain}
            onBackToLobby={handleBackToLobby}
          />
        )}
      </AnimatePresence>
    </div>
  );
}