import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { useAuth } from '../contexts/AuthContext';
import toast from 'react-hot-toast';

const AVATARS = [
  { id: 'default', emoji: '😀', name: 'Padrão' },
  { id: 'cowboy', emoji: '🤠', name: 'Cowboy' },
  { id: 'pirate', emoji: '🏴‍☠️', name: 'Pirata' },
  { id: 'ninja', emoji: '🥷', name: 'Ninja' },
  { id: 'astronaut', emoji: '👨‍🚀', name: 'Astronauta' },
  { id: 'wizard', emoji: '🧙', name: 'Mago' },
  { id: 'robot', emoji: '🤖', name: 'Robô' },
  { id: 'alien', emoji: '👽', name: 'Alien' },
  { id: 'crown', emoji: '👑', name: 'Coroa' },
  { id: 'fire', emoji: '🔥', name: 'Fogo' },
];

export default function Profile() {
  const { user, api, refreshUser } = useAuth();
  const [selectedAvatar, setSelectedAvatar] = useState(user?.avatar || 'default');

  const totalGames = user?.totalGames || user?.total_games || 0;
  const totalWins = user?.totalWins || user?.total_wins || 0;
  const totalLosses = user?.totalLosses || user?.total_losses || 0;
  const winRate = totalGames > 0 ? ((totalWins / totalGames) * 100).toFixed(1) : 0;

  const handleAvatarChange = async (avatarId) => {
    try {
      await api.put('/user/avatar', { avatar: avatarId });
      setSelectedAvatar(avatarId);
      await refreshUser();
      toast.success('Avatar atualizado!');
    } catch (error) {
      toast.error('Erro ao atualizar avatar');
    }
  };

  const currentAvatar = AVATARS.find(a => a.id === (user?.avatar || 'default'));

  return (
    <div className="max-w-2xl mx-auto px-4 py-8">
      <motion.div
        initial={{ y: 20, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
      >
        {/* Profile Header */}
        <div className="card-container text-center mb-6">
          <div className="text-6xl mb-3">{currentAvatar?.emoji || '😀'}</div>
          <h1 className="text-3xl font-bold text-gold-400">{user?.nickname}</h1>
          <p className="text-felt-400 text-sm">ID: #{user?.player_id || user?.playerId}</p>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-4 gap-3 mb-6">
          <div className="card-container text-center">
            <div className="text-2xl font-bold text-white">{totalGames}</div>
            <div className="text-xs text-felt-400">Partidas</div>
          </div>
          <div className="card-container text-center">
            <div className="text-2xl font-bold text-emerald-400">{totalWins}</div>
            <div className="text-xs text-felt-400">Vitórias</div>
          </div>
          <div className="card-container text-center">
            <div className="text-2xl font-bold text-red-400">{totalLosses}</div>
            <div className="text-xs text-felt-400">Derrotas</div>
          </div>
          <div className="card-container text-center">
            <div className="text-2xl font-bold text-gold-400">{winRate}%</div>
            <div className="text-xs text-felt-400">Taxa</div>
          </div>
        </div>

        {/* Avatar Selection */}
        <div className="card-container mb-6">
          <h2 className="text-xl font-bold text-gold-400 mb-4">Escolher Avatar</h2>
          <div className="grid grid-cols-5 gap-3">
            {AVATARS.map(avatar => (
              <motion.button
                key={avatar.id}
                whileHover={{ scale: 1.1 }}
                whileTap={{ scale: 0.9 }}
                onClick={() => handleAvatarChange(avatar.id)}
                className={`flex flex-col items-center gap-1 p-3 rounded-xl transition-all ${
                  selectedAvatar === avatar.id
                    ? 'bg-gold-500/20 border-2 border-gold-500'
                    : 'bg-felt-800 border-2 border-transparent hover:border-felt-600'
                }`}
              >
                <span className="text-3xl">{avatar.emoji}</span>
                <span className="text-xs text-felt-400">{avatar.name}</span>
              </motion.button>
            ))}
          </div>
        </div>

        {/* Balance */}
        <div className="card-container">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-lg font-bold text-gold-400">Saldo</h2>
              <p className="text-3xl font-bold text-white mt-1">
                🪙 {(user?.coins || 0).toFixed(2)}
              </p>
              <p className="text-sm text-felt-400">= R$ {(user?.coins || 0).toFixed(2)}</p>
            </div>
            <div className="flex flex-col gap-2">
              <a href="/store" className="btn-primary text-sm">
                💰 Comprar Moedas
              </a>
            </div>
          </div>
        </div>
      </motion.div>
    </div>
  );
}