import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { useAuth } from '../contexts/AuthContext';

export default function History() {
  const { api } = useAuth();
  const [games, setGames] = useState([]);
  const [transactions, setTransactions] = useState([]);
  const [tab, setTab] = useState('games');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      const [gamesRes, transRes] = await Promise.all([
        api.get('/user/history'),
        api.get('/payment/transactions'),
      ]);
      setGames(gamesRes.data);
      setTransactions(transRes.data);
    } catch (error) {
      console.error('Erro ao carregar histórico:', error);
    } finally {
      setLoading(false);
    }
  };

  const formatDate = (date) => {
    return new Date(date).toLocaleDateString('pt-BR', {
      day: '2-digit',
      month: '2-digit',
      year: '2-digit',
      hour: '2-digit',
      minute: '2-digit',
    });
  };

  const transactionTypeLabels = {
    deposit: { label: 'Depósito', icon: '💰', color: 'text-emerald-400' },
    withdrawal: { label: 'Saque', icon: '💸', color: 'text-orange-400' },
    bet: { label: 'Aposta', icon: '🎲', color: 'text-red-400' },
    win: { label: 'Vitória', icon: '🏆', color: 'text-gold-400' },
    rake: { label: 'Rake', icon: '🏠', color: 'text-felt-400' },
    refund: { label: 'Devolução', icon: '↩️', color: 'text-blue-400' },
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[50vh]">
        <div className="animate-spin rounded-full h-12 w-12 border-4 border-gold-500 border-t-transparent"></div>
      </div>
    );
  }

  return (
    <div className="max-w-3xl mx-auto px-4 py-8">
      <motion.div initial={{ y: 20, opacity: 0 }} animate={{ y: 0, opacity: 1 }}>
        <h1 className="text-3xl font-bold text-gold-400 mb-6">📊 Histórico</h1>

        {/* Tabs */}
        <div className="flex gap-2 mb-6">
          <button
            onClick={() => setTab('games')}
            className={`px-4 py-2 rounded-lg font-medium transition-all ${
              tab === 'games'
                ? 'bg-gold-500 text-felt-950'
                : 'bg-felt-800 text-felt-300 hover:bg-felt-700'
            }`}
          >
            🎮 Partidas ({games.length})
          </button>
          <button
            onClick={() => setTab('transactions')}
            className={`px-4 py-2 rounded-lg font-medium transition-all ${
              tab === 'transactions'
                ? 'bg-gold-500 text-felt-950'
                : 'bg-felt-800 text-felt-300 hover:bg-felt-700'
            }`}
          >
            💰 Financeiro ({transactions.length})
          </button>
        </div>

        {/* Games tab */}
        {tab === 'games' && (
          <div className="space-y-3">
            {games.length === 0 ? (
              <div className="card-container text-center py-12">
                <div className="text-4xl mb-3">🃏</div>
                <p className="text-felt-400">Nenhuma partida jogada ainda</p>
                <a href="/lobby" className="btn-primary mt-4 inline-block">
                  Jogar agora!
                </a>
              </div>
            ) : (
              games.map((game, index) => (
                <motion.div
                  key={game.id}
                  initial={{ x: -20, opacity: 0 }}
                  animate={{ x: 0, opacity: 1 }}
                  transition={{ delay: index * 0.05 }}
                  className="card-container flex items-center justify-between"
                >
                  <div className="flex items-center gap-3">
                    <span className="text-2xl">{game.is_winner ? '🏆' : '❌'}</span>
                    <div>
                      <div className="font-medium">
                        {game.mode === 'free' ? 'Modo Grátis' : `Aposta: ${game.bet_amount} 🪙`}
                      </div>
                      <div className="text-xs text-felt-400">
                        {formatDate(game.finished_at)}
                      </div>
                    </div>
                  </div>
                  <div className={`font-bold ${
                    game.coins_change > 0 ? 'text-emerald-400' : game.coins_change < 0 ? 'text-red-400' : 'text-felt-400'
                  }`}>
                    {game.coins_change > 0 ? '+' : ''}{parseFloat(game.coins_change).toFixed(2)} 🪙
                  </div>
                </motion.div>
              ))
            )}
          </div>
        )}

        {/* Transactions tab */}
        {tab === 'transactions' && (
          <div className="space-y-3">
            {transactions.length === 0 ? (
              <div className="card-container text-center py-12">
                <div className="text-4xl mb-3">💰</div>
                <p className="text-felt-400">Nenhuma transação ainda</p>
              </div>
            