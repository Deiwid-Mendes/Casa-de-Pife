import React from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';

export default function Home() {
  return (
    <div className="min-h-screen flex flex-col">
      {/* Hero */}
      <div className="flex-1 flex items-center justify-center px-4 py-12">
        <div className="max-w-4xl mx-auto text-center">
          <motion.div
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            transition={{ type: 'spring', stiffness: 200 }}
            className="text-7xl md:text-8xl mb-6"
          >
            🃏
          </motion.div>

          <motion.h1
            initial={{ y: 20, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ delay: 0.2 }}
            className="text-5xl md:text-7xl font-bold mb-4"
          >
            <span className="text-gold-400">Casa de </span>
            <span className="text-white">Pife</span>
          </motion.h1>

          <motion.p
            initial={{ y: 20, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ delay: 0.3 }}
            className="text-xl md:text-2xl text-felt-300 mb-8 max-w-2xl mx-auto"
          >
            O melhor jogo de Pife (Pif Paf) online do Brasil.
            Jogue contra jogadores reais e mostre sua habilidade!
          </motion.p>

          <motion.div
            initial={{ y: 20, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ delay: 0.4 }}
            className="flex flex-col sm:flex-row gap-4 justify-center"
          >
            <Link to="/register" className="btn-primary text-lg px-8 py-4 inline-block">
              🚀 Criar Conta Grátis
            </Link>
            <Link to="/login" className="btn-secondary text-lg px-8 py-4 inline-block">
              🔑 Entrar
            </Link>
          </motion.div>

          {/* Features */}
          <motion.div
            initial={{ y: 30, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ delay: 0.6 }}
            className="grid md:grid-cols-3 gap-6 mt-16"
          >
            <div className="card-container">
              <div className="text-3xl mb-3">🎯</div>
              <h3 className="text-lg font-bold text-gold-400 mb-2">Jogo de Habilidade</h3>
              <p className="text-felt-400 text-sm">
                Seu resultado depende da sua estratégia, não da sorte!
              </p>
            </div>

            <div className="card-container">
              <div className="text-3xl mb-3">👥</div>
              <h3 className="text-lg font-bold text-gold-400 mb-2">100% Jogadores Reais</h3>
              <p className="text-felt-400 text-sm">
                Sem bots, sem IA. Apenas jogadores reais competindo.
              </p>
            </div>

            <div className="card-container">
              <div className="text-3xl mb-3">⚡</div>
              <h3 className="text-lg font-bold text-gold-400 mb-2">PIX Instantâneo</h3>
              <p className="text-felt-400 text-sm">
                Deposite e saque via PIX em segundos. Sem burocracia.
              </p>
            </div>
          </motion.div>
        </div>
      </div>

      {/* Footer */}
      <footer className="text-center py-6 text-felt-600 text-sm border-t border-felt-800">
        <p>🔞 Proibido para menores de 18 anos. Jogue com responsabilidade.</p>
        <p className="mt-1">© 2024 Casa de Pife. Jogo de habilidade.</p>
      </footer>
    </div>
  );
}