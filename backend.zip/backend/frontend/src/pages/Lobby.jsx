import React, { useState, useEffect, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import { AnimatePresence } from 'framer-motion';
import { useAuth } from '../contexts/AuthContext';
import { useSocket } from '../contexts/SocketContext';
import LobbyMain from '../components/Lobby/LobbyMain';
import CreateRoom from '../components/Lobby/CreateRoom';
import JoinRoom from '../components/Lobby/JoinRoom';
import MatchmakingQueue from '../components/Lobby/MatchmakingQueue';
import toast from 'react-hot-toast';

export default function Lobby() {
  const { user } = useAuth();
  const { socket, connected } = useSocket();
  const navigate = useNavigate();

  const [showCreateRoom, setShowCreateRoom] = useState(false);
  const [showJoinRoom, setShowJoinRoom] = useState(false);
  const [showMatchmaking, setShowMatchmaking] = useState(false);
  const [matchmakingInfo, setMatchmakingInfo] = useState({});
  const [queueSizes, setQueueSizes] = useState({});

  useEffect(() => {
    if (!socket) return;

    socket.on('matchmaking:queue_sizes', (sizes) => {
      setQueueSizes(sizes);
    });

    socket.on('matchmaking:waiting', (info) => {
      setMatchmakingInfo(info);
    });

    socket.on('matchmaking:found', ({ roomId }) => {
      setShowMatchmaking(false);
      toast.success('Oponente encontrado! 🎮');
      navigate(`/game/${roomId}`);
    });

    socket.on('room:created', ({ roomId, password }) => {
      setShowCreateRoom(false);
      toast.success(`Sala criada! ID: ${roomId}`, { duration: 8000 });
      navigate(`/game/${roomId}`);
    });

    socket.on('room:joined', ({ roomId }) => {
      setShowJoinRoom(false);
      toast.success('Entrou na sala! 🎮');
      navigate(`/game/${roomId}`);
    });

    return () => {
      socket.off('matchmaking:queue_sizes');
      socket.off('matchmaking:waiting');
      socket.off('matchmaking:found');
      socket.off('room:created');
      socket.off('room:joined');
    };
  }, [socket, navigate]);

  const handleFreePlay = useCallback(() => {
    if (!socket || !connected) return toast.error('Conectando...');
    socket.emit('matchmaking:join', { betAmount: 0 });
    setShowMatchmaking(true);
  }, [socket, connected]);

  const handleMatchmaking = useCallback((betAmount) => {
    if (!socket || !connected) return toast.error('Conectando...');
    if (user.coins < betAmount) {
      return toast.error('Saldo insuficiente! Compre moedas na loja.');
    }
    socket.emit('matchmaking:join', { betAmount });
    setShowMatchmaking(true);
  }, [socket, connected, user]);

  const handleCreateRoom = useCallback((config) => {
    if (!socket || !connected) return toast.error('Conectando...');
    socket.emit('room:create', config);
  }, [socket, connected]);

  const handleJoinRoom = useCallback((roomId, password) => {
    if (!socket || !connected) return toast.error('Conectando...');
    socket.emit('room:join', { roomId, password });
  }, [socket, connected]);

  const handleCancelMatchmaking = useCallback(() => {
    if (socket) {
      socket.emit('matchmaking:leave');
    }
    setShowMatchmaking(false);
  }, [socket]);

  if (!user) return null;

  return (
    <>
      <LobbyMain
        user={user}
        queueSizes={queueSizes}
        onFreePlay={handleFreePlay}
        onMatchmaking={handleMatchmaking}
        onCreateRoom={() => setShowCreateRoom(true)}
        onJoinRoom={() => setShowJoinRoom(true)}
      />

      {/* Connection indicator */}
      <div className={`fixed bottom-4 left-4 px-3 py-1 rounded-full text-xs flex items-center gap-1 ${
        connected ? 'bg-emerald-900/50 text-emerald-400' : 'bg-red-900/50 text-red-400'
      }`}>
        <div className={`w-2 h-2 rounded-full ${connected ? 'bg-emerald-400' : 'bg-red-400 animate-pulse'}`} />
        {connected ? 'Conectado' : 'Reconectando...'}
      </div>

      <AnimatePresence>
        {showCreateRoom && (
          <CreateRoom
            onClose={() => setShowCreateRoom(false)}
            onCreateRoom={handleCreateRoom}
          />
        )}

        {showJoinRoom && (
          <JoinRoom
            onClose={() => setShowJoinRoom(false)}
            onJoinRoom={handleJoinRoom}
          />
        )}

        {showMatchmaking && (
          <MatchmakingQueue
            onCancel={handleCancelMatchmaking}
            position={matchmakingInfo.position}
            estimatedWait={matchmakingInfo.estimatedWait}
          />
        )}
      </AnimatePresence>
    </>
  );
}