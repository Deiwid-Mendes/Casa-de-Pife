import React from 'react';
import ReactDOM from 'react-dom/client';
import { BrowserRouter } from 'react-router-dom';
import { Toaster } from 'react-hot-toast';
import App from './App';
import './index.css';

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <BrowserRouter>
      <App />
      <Toaster
        position="top-center"
        toastOptions={{
          duration: 4000,
          style: {
            background: '#166534',
            color: '#fff',
            border: '1px solid #15803d',
          },
          success: {
            iconTheme: {
              primary: '#fbbf24',
              secondary: '#166534',
            },
          },
          error: {
            style: {
              background: '#991b1b',
              border: '1px solid #dc2626',
            },
          },
        }}
      />
    </BrowserRouter>
  </React.StrictMode>
);