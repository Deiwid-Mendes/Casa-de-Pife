const validator = require('validator');

const validateRegistration = (req, res, next) => {
  const { nickname, email, password, birthDate } = req.body;
  const errors = [];

  // Nickname
  if (!nickname || nickname.length < 3 || nickname.length > 20) {
    errors.push('Nickname deve ter entre 3 e 20 caracteres');
  }
  if (nickname && !/^[a-zA-Z0-9_]+$/.test(nickname)) {
    errors.push('Nickname pode conter apenas letras, números e underscore');
  }

  // Email
  if (!email || !validator.isEmail(email)) {
    errors.push('E-mail inválido');
  }

  // Senha
  if (!password || password.length < 6) {
    errors.push('Senha deve ter no mínimo 6 caracteres');
  }

  // Data de nascimento (18+)
  if (!birthDate) {
    errors.push('Data de nascimento é obrigatória');
  } else {
    const birth = new Date(birthDate);
    const today = new Date();
    const age = today.getFullYear() - birth.getFullYear();
    const monthDiff = today.getMonth() - birth.getMonth();
    const actualAge = monthDiff < 0 || (monthDiff === 0 && today.getDate() < birth.getDate())
      ? age - 1
      : age;
    if (actualAge < 18) {
      errors.push('Você deve ter 18 anos ou mais para se cadastrar');
    }
  }

  if (errors.length > 0) {
    return res.status(400).json({ errors });
  }

  next();
};

const validateLogin = (req, res, next) => {
  const { email, password } = req.body;
  const errors = [];

  if (!email || !validator.isEmail(email)) {
    errors.push('E-mail inválido');
  }
  if (!password) {
    errors.push('Senha é obrigatória');
  }

  if (errors.length > 0) {
    return res.status(400).json({ errors });
  }

  next();
};

module.exports = { validateRegistration, validateLogin };