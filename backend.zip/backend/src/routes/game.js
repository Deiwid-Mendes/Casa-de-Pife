const express = require('express');
const authMiddleware = require('../middleware/auth');
const router = express.Router();

// GET /api/game/active-rooms
router.get('/active-rooms', authMiddleware, (req, res) => {
  // As salas ativas ficam na memória / Redis, gerenciadas pelo SocketHandler
  res.json({ message: 'Use WebSocket para interagir com salas de jogo' });
});

module.exports = router;