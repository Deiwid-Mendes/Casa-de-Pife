const express = require('express');
const User = require('../models/User');
const GameHistory = require('../models/GameHistory');
const authMiddleware = require('../middleware/auth');
const router = express.Router();

// GET /api/user/profile
router.get('/profile', authMiddleware, async (req, res) => {
  try {
    const user = await User.findById(req.user.id);
    if (!user) {
      return res.status(404).json({ error: 'Usuário não encontrado' });
    }

    const winRate = user.total_games > 0
      ? ((user.total_wins / user.total_games) * 100).toFixed(1)
      : 0;

    res.json({
      ...user,
      coins: parseFloat(user.coins),
      winRate: parseFloat(winRate),
    });
  } catch (error) {
    res.status(500).json({ error: 'Erro ao buscar perfil' });
  }
});

// GET /api/user/history
router.get('/history', authMiddleware, async (req, res) => {
  try {
    const history = await GameHistory.getByUser(req.user.id);
    res.json(history);
  } catch (error) {
    res.status(500).json({ error: 'Erro ao buscar histórico' });
  }
});

// PUT /api/user/avatar
router.put('/avatar', authMiddleware, async (req, res) => {
  try {
    const { avatar } = req.body;
    const validAvatars = [
      'default', 'cowboy', 'pirate', 'ninja', 'astronaut',
      'wizard', 'robot', 'alien', 'crown', 'fire'
    ];

    if (!validAvatars.includes(avatar)) {
      return res.status(400).json({ error: 'Avatar inválido' });
    }

    await User.updateAvatar(req.user.id, avatar);
    res.json({ message: 'Avatar atualizado', avatar });
  } catch (error) {
    res.status(500).json({ error: 'Erro ao atualizar avatar' });
  }
});

// GET /api/user/balance
router.get('/balance', authMiddleware, async (req, res) => {
  try {
    const coins = await User.getCoins(req.user.id);
    res.json({ coins: parseFloat(coins) });
  } catch (error) {
    res.status(500).json({ error: 'Erro ao buscar saldo' });
  }
});

module.exports = router;