const express = require('express');
const User = require('../models/User');
const Transaction = require('../models/Transaction');
const authMiddleware = require('../middleware/auth');
const router = express.Router();

const COIN_PACKAGES = [
  { id: 'basic', name: 'Básico', price: 5, coins: 5 },
  { id: 'bronze', name: 'Bronze', price: 10, coins: 10 },
  { id: 'silver', name: 'Prata', price: 20, coins: 20 },
  { id: 'gold', name: 'Ouro', price: 30, coins: 30 },
  { id: 'diamond', name: 'Diamante', price: 50, coins: 50 },
];

// GET /api/payment/packages
router.get('/packages', (req, res) => {
  res.json(COIN_PACKAGES);
});

// POST /api/payment/deposit
router.post('/deposit', authMiddleware, async (req, res) => {
  try {
    const { packageId, paymentMethod } = req.body;

    const pkg = COIN_PACKAGES.find(p => p.id === packageId);
    if (!pkg) {
      return res.status(400).json({ error: 'Pacote inválido' });
    }

    if (!['pix', 'credit_card', 'debit_card', 'boleto'].includes(paymentMethod)) {
      return res.status(400).json({ error: 'Método de pagamento inválido' });
    }

    // Verificar limite de depósito
    const user = await User.findById(req.user.id);
    if (user.self_excluded) {
      return res.status(403).json({ error: 'Conta em autoexclusão' });
    }

    // Simular processamento do pagamento (em produção: integrar com gateway)
    const transaction = await Transaction.create({
      userId: req.user.id,
      type: 'deposit',
      amount: pkg.price,
      status: paymentMethod === 'boleto' ? 'pending' : 'completed',
      paymentMethod,
      description: `Compra do pacote ${pkg.name} - ${pkg.coins} moedas`,
    });

    // Se não for boleto, creditar imediatamente
    if (paymentMethod !== 'boleto') {
      await User.updateCoins(req.user.id, pkg.coins);
    }

    // Simular dados de PIX
    let paymentData = {};
    if (paymentMethod === 'pix') {
      paymentData = {
        pixKey: '12345678900',
        pixQrCode: 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUg...',
        pixCopyPaste: '00020126580014br.gov.bcb.pix0136...',
        expiresIn: '30 minutos',
      };
    }

    const updatedCoins = await User.getCoins(req.user.id);

    res.json({
      message: paymentMethod === 'boleto'
        ? 'Boleto gerado. Moedas serão creditadas após confirmação.'
        : `${pkg.coins} moedas adicionadas com sucesso!`,
      transaction,
      paymentData,
      newBalance: parseFloat(updatedCoins),
    });
  } catch (error) {
    console.error('Erro no depósito:', error);
    res.status(500).json({ error: 'Erro ao processar pagamento' });
  }
});

// POST /api/payment/withdraw
router.post('/withdraw', authMiddleware, async (req, res) => {
  try {
    const { amount, pixKey } = req.body;

    const minWithdrawal = parseFloat(process.env.MIN_WITHDRAWAL || 10);
    const feePercentage = parseFloat(process.env.WITHDRAWAL_FEE_PERCENTAGE || 2);

    if (!amount || amount < minWithdrawal) {
      return res.status(400).json({
        error: `Saque mínimo: ${minWithdrawal} moedas (R$ ${minWithdrawal.toFixed(2)})`,
      });
    }

    if (!pixKey) {
      return res.status(400).json({ error: 'Chave PIX é obrigatória' });
    }

    const currentCoins = await User.getCoins(req.user.id);
    if (parseFloat(currentCoins) < amount) {
      return res.status(400).json({ error: 'Saldo insuficiente' });
    }

    const fee = (amount * feePercentage) / 100;
    const netAmount = amount - fee;

    // Debitar moedas
    await User.updateCoins(req.user.id, -amount);

    // Registrar transação
    const transaction = await Transaction.create({
      userId: req.user.id,
      type: 'withdrawal',
      amount: netAmount,
      status: 'pending',
      paymentMethod: 'pix',
      description: `Saque de ${amount} moedas (taxa: ${fee.toFixed(2)}) para PIX: ${pixKey}`,
    });

    res.json({
      message: 'Saque solicitado com sucesso! Processamento em até 24h.',
      grossAmount: amount,
      fee: fee,
      netAmount: netAmount,
      transaction,
    });
  } catch (error) {
    console.error('Erro no saque:', error);
    res.status(500).json({ error: 'Erro ao processar saque' });
  }
});

// GET /api/payment/transactions
router.get('/transactions', authMiddleware, async (req, res) => {
  try {
    const transactions = await Transaction.getByUser(req.user.id);
    res.json(transactions);
  } catch (error) {
    res.status(500).json({ error: 'Erro ao buscar transações' });
  }
});

module.exports = router;