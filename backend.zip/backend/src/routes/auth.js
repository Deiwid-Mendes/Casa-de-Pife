const express = require('express');
const jwt = require('jsonwebtoken');
const User = require('../models/User');
const { validateRegistration, validateLogin } = require('../middleware/validation');
const router = express.Router();

// POST /api/auth/register
router.post('/register', validateRegistration, async (req, res) => {
  try {
    const { nickname, email, password, birthDate } = req.body;

    // Verificar duplicatas
    const existingEmail = await User.findByEmail(email);
    if (existingEmail) {
      return res.status(409).json({ error: 'E-mail já cadastrado' });
    }

    const existingNickname = await User.findByNickname(nickname);
    if (existingNickname) {
      return res.status(409).json({ error: 'Nickname já em uso' });
    }

    const { user, emailToken } = await User.create({ nickname, email, password, birthDate });

    // Em produção, enviar e-mail de verificação
    console.log(`📧 Token de verificação para ${email}: ${emailToken}`);

    const token = jwt.sign({ userId: user.id }, process.env.JWT_SECRET, {
      expiresIn: process.env.JWT_EXPIRES_IN,
    });

    res.status(201).json({
      message: 'Cadastro realizado com sucesso! Verifique seu e-mail.',
      token,
      user: {
        id: user.id,
        nickname: user.nickname,
        email: user.email,
        playerId: user.player_id,
        coins: parseFloat(user.coins),
        avatar: user.avatar,
      },
    });
  } catch (error) {
    console.error('Erro no registro:', error);
    res.status(500).json({ error: 'Erro interno do servidor' });
  }
});

// POST /api/auth/login
router.post('/login', validateLogin, async (req, res) => {
  try {
    const { email, password } = req.body;

    const user = await User.findByEmail(email);
    if (!user) {
      return res.status(401).json({ error: 'E-mail ou senha incorretos' });
    }

    const validPassword = await User.comparePassword(password, user.password_hash);
    if (!validPassword) {
      return res.status(401).json({ error: 'E-mail ou senha incorretos' });
    }

    if (user.is_banned) {
      return res.status(403).json({ error: 'Conta suspensa. Entre em contato com o suporte.' });
    }

    const token = jwt.sign({ userId: user.id }, process.env.JWT_SECRET, {
      expiresIn: process.env.JWT_EXPIRES_IN,
    });

    res.json({
      token,
      user: {
        id: user.id,
        nickname: user.nickname,
        email: user.email,
        playerId: user.player_id,
        coins: parseFloat(user.coins),
        avatar: user.avatar,
        totalGames: user.total_games,
        totalWins: user.total_wins,
        totalLosses: user.total_losses,
      },
    });
  } catch (error) {
    console.error('Erro no login:', error);
    res.status(500).json({ error: 'Erro interno do servidor' });
  }
});

// GET /api/auth/verify-email/:token
router.get('/verify-email/:token', async (req, res) => {
  try {
    const user = await User.verifyEmail(req.params.token);
    if (!user) {
      return res.status(400).json({ error: 'Token inválido ou expirado' });
    }
    res.json({ message: 'E-mail verificado com sucesso!' });
  } catch (error) {
    res.status(500).json({ error: 'Erro ao verificar e-mail' });
  }
});

module.exports = router;