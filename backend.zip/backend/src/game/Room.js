const Deck = require('./Deck');
const PifeValidator = require('./PifeValidator');
const { v4: uuidv4 } = require('uuid');

class Room {
  constructor({ id, name, mode, betAmount, maxPlayers, maxRounds, turnTime, password, creatorId }) {
    this.id = id || `SALA-${Math.floor(1000 + Math.random() * 9000)}`;
    this.name = name || `Sala ${this.id}`;
    this.mode = mode; // 'free', 'matchmaking', 'private'
    this.betAmount = betAmount || 0;
    this.maxPlayers = maxPlayers || 2;
    this.maxRounds = maxRounds || 1;
    this.turnTime = turnTime || 45; // seconds
    this.password = password || null;
    this.creatorId = creatorId;

    this.players = new Map(); // userId -> playerData
    this.spectators = [];
    this.state = 'waiting'; // waiting, playing, finished
    this.currentRound = 0;
    this.roundScores = {};

    // Game state
    this.deck = null;
    this.discardPile = [];
    this.currentPlayerIndex = 0;
    this.turnOrder = [];
    this.phase = 'buy'; // 'buy' or 'discard'
    this.turnTimer = null;
    this.turnStartTime = null;
    this.startedAt = null;
    this.gameLog = [];

    this.rakePercentage = parseFloat(process.env.RAKE_PERCENTAGE || 5);
  }

  addPlayer(userId, nickname, avatar, socketId) {
    if (this.players.size >= this.maxPlayers) {
      throw new Error('Sala cheia');
    }
    if (this.state !== 'waiting') {
      throw new Error('Partida já em andamento');
    }

    this.players.set(userId, {
      id visité userId,
      nickname,
      avatar,
      socketId,
      hand: [],
      ready: false,
      connected: true,
      isPifado: false,
      winningCards: [],
    });

    this.roundScores[userId] = 0;
  }

  removePlayer(userId) {
    this.players.delete(userId);
    delete this.roundScores[userId];
  }

  setReady(userId) {
    const player = this.players.get(userId);
    if (player) {
      player.ready = true;
    }
  }

  allReady() {
    if (this.players.size < 2) return false;
    return Array.from(this.players.values()).every(p => p.ready);
  }

  startGame() {
    if (!this.allReady()) {
      throw new Error('Nem todos os jogadores estão prontos');
    }

    this.state = 'playing';
    this.currentRound++;
    this.startedAt = new Date();
    this.deck = new Deck();
    this.discardPile = [];
    this.turnOrder = Array.from(this.players.keys());
    this.currentPlayerIndex = 0;
    this.phase = 'buy';
    this.gameLog = [];

    // Distribuir 9 cartas para cada jogador
    for (const [userId, player] of this.players) {
      player.hand = this.deck.drawMultiple(9);
      player.isPifado = false;
      player.winningCards = [];
      player.ready = false;
    }

    // Primeira carta para o lixo
    const firstDiscard = this.deck.draw();
    this.discardPile.push(firstDiscard);

    this.log('game_start', { round: this.currentRound });
    this.turnStartTime = Date.now();

    return this.getGameState();
  }

  getCurrentPlayerId() {
    return this.turnOrder[this.currentPlayerIndex];
  }

  getCurrentPlayer() {
    return this.players.get(this.getCurrentPlayerId());
  }

  // Comprar carta do monte
  buyFromDeck(userId) {
    if (this.getCurrentPlayerId() !== userId) {
      throw new Error('Não é sua vez');
    }
    if (this.phase !== 'buy') {
      throw new Error('Você já comprou neste turno');
    }
    if (this.deck.isEmpty()) {
      throw new Error('Monte vazio');
    }

    const card = this.deck.draw();
    const player = this.players.get(userId);
    player.hand.push(card);
    this.phase = 'discard';

    this.log('buy_deck', { userId, card: card.id });

    // Verificar se pode bater automaticamente
    const canBat = PifeValidator.canBat(player.hand);

    return {
      card,
      canBat: !!canBat,
      groups: canBat || null,
      deckRemaining: this.deck.remaining(),
    };
  }

  // Comprar carta do lixo
  buyFromDiscard(userId) {
    if (this.getCurrentPlayerId() !== userId) {
      throw new Error('Não é sua vez');
    }
    if (this.phase !== 'buy') {
      throw new Error('Você já comprou neste turno');
    }
    if (this.discardPile.length === 0) {
      throw new Error('Lixo vazio');
    }

    const card = this.discardPile.pop();
    const player = this.players.get(userId);
    player.hand.push(card);
    this.phase = 'discard';

    this.log('buy_discard', { userId, card: card.id });

    const canBat = PifeValidator.canBat(player.hand);

    return {
      card,
      canBat: !!canBat,
      groups: canBat || null,
      topDiscard: this.discardPile[this.discardPile.length - 1] || null,
    };
  }

  // Descartar carta
  discard(userId, cardId) {
    if (this.getCurrentPlayerId() !== userId) {
      throw new Error('Não é sua vez');
    }
    if (this.phase !== 'discard') {
      throw new Error('Você precisa comprar primeiro');
    }

    const player = this.players.get(userId);
    const cardIndex = player.hand.findIndex(c => c.id === cardId);

    if (cardIndex === -1) {
      throw new Error('Carta não encontrada na sua mão');
    }

    const card = player.hand.splice(cardIndex, 1)[0];
    this.discardPile.push(card);

    this.log('discard', { userId, card: card.id });

    // Verificar se o jogador está pifado
    player.isPifado = PifeValidator.isPifado(player.hand);

    // Verificar se algum jogador pifado pode bater com esta carta
    const interceptors = this.checkInterception(card, userId);

    // Avançar turno
    this.nextTurn();

    return {
      discardedCard: card,
      isPifado: player.isPifado,
      interceptors,
      deckRemaining: this.deck.remaining(),
      deckEmpty: this.deck.isEmpty(),
    };
  }

  // Verificar se alguém pode interceptar o descarte para bater
  checkInterception(discardedCard, discarderId) {
    const interceptors = [];
    const discarderIdx = this.turnOrder.indexOf(discarderId);

    for (let offset = 1; offset < this.turnOrder.length; offset++) {
      const idx = (discarderIdx + offset) % this.turnOrder.length;
      const playerId = this.turnOrder[idx];
      const player = this.players.get(playerId);

      if (player.isPifado) {
        const result = PifeValidator.canBatWithCard(player.hand, discardedCard);
        if (result) {
          interceptors.push({
            playerId,
            priority: offset, // Menor = mais próximo (sentido horário)
          });
        }
      }
    }

    return interceptors.sort((a, b) => a.priority - b.priority);
  }

  // Jogador bate (vence)
  bat(userId) {
    const player = this.players.get(userId);
    if (!player) {
      throw new Error('Jogador não encontrado');
    }

    // Verificar se a mão tem 9 cartas e forma 3 combinações válidas
    let groups;
    if (player.hand.length === 10) {
      // Precisa descartar uma carta primeiro - verificar todas as possibilidades
      for (let i = 0; i < player.hand.length; i++) {
        const testHand = player.hand.filter((_, idx) => idx !== i);
        const result = PifeValidator.canBat(testHand);
        if (result) {
          // Descartar a carta e bater
          const discarded = player.hand.splice(i, 1)[0];
          this.discardPile.push(discarded);
          groups = result;
          break;
        }
      }
    } else if (player.hand.length === 9) {
      groups = PifeValidator.canBat(player.hand);
    }

    if (!groups) {
      throw new Error('Mão inválida para bater');
    }

    this.log('bat', { userId, groups: groups.map(g => g.map(c => c.id)) });

    return this.endRound(userId, groups);
  }

  // Interceptar descarte para bater (quando pifado)
  interceptBat(userId) {
    const player = this.players.get(userId);
    if (!player || !player.isPifado) {
      throw new Error('Você precisa estar pifado para interceptar');
    }

    if (this.discardPile.length === 0) {
      throw new Error('Nenhuma carta no lixo');
    }

    const topDiscard = this.discardPile[this.discardPile.length - 1];
    const result = PifeValidator.canBatWithCard(player.hand, topDiscard);

    if (!result) {
      throw new Error('Essa carta não completa sua mão');
    }

    // Pegar carta do lixo
    const card = this.discardPile.pop();
    player.hand.push(card);

    // Descartar a carta desnecessária
    const discarded = player.hand.splice(result.discardIndex, 1)[0];
    this.discardPile.push(discarded);

    this.log('intercept_bat', { userId, card: card.id });

    return this.endRound(userId, result.groups);
  }

  endRound(winnerId, winnerGroups) {
    this.state = 'finished';

    if (this.turnTimer) {
      clearTimeout(this.turnTimer);
    }

    const rakeAmount = this.mode !== 'free'
      ? (this.betAmount * this.players.size * this.rakePercentage) / 100
      : 0;

    const potAmount = this.betAmount * this.players.size;
    const winAmount = potAmount - rakeAmount;

    const results = {
      winnerId,
      winnerGroups,
      winAmount,
      rakeAmount,
      potAmount,
      players: {},
      duration: Math.floor((Date.now() - this.startedAt.getTime()) / 1000),
    };

    for (const [userId, player] of this.players) {
      const isWinner = userId === winnerId;
      const penalty = isWinner ? 0 : PifeValidator.calculatePenalty(player.hand);

      results.players[userId] = {
        nickname: player.nickname,
        hand: player.hand,
        isWinner,
        coinsChange: isWinner ? winAmount - this.betAmount : -this.betAmount,
        penaltyPoints: penalty,
      };
    }

    return results;
  }

  // Monte acabou sem ninguém bater
  handleEmptyDeck() {
    this.state = 'finished';
    if (this.turnTimer) {
      clearTimeout(this.turnTimer);
    }

    const results = {
      winnerId: null,
      draw: true,
      refund: true,
      players: {},
    };

    for (const [userId, player] of this.players) {
      results.players[userId] = {
        nickname: player.nickname,
        hand: player.hand,
        isWinner: false,
        coinsChange: 0, // Devolução
        penaltyPoints: 0,
      };
    }

    return results;
  }

  nextTurn() {
    this.currentPlayerIndex = (this.currentPlayerIndex + 1) % this.turnOrder.length;
    this.phase = 'buy';
    this.turnStartTime = Date.now();

    // Verificar se o monte acabou
    if (this.deck.isEmpty()) {
      return this.handleEmptyDeck();
    }

    return null;
  }

  // Auto-discard por timeout
  autoPlay(userId) {
    const player = this.players.get(userId);
    if (!player) return null;

    if (this.phase === 'buy') {
      // Comprar do monte automaticamente
      this.buyFromDeck(userId);
    }

    // Descartar a última carta adicionada
    if (player.hand.length === 10) {
      const cardToDiscard = player.hand[player.hand.length - 1];
      return this.discard(userId, cardToDiscard.id);
    }

    return null;
  }

  getGameState(forUserId = null) {
    const state = {
      roomId: this.id,
      roomName: this.name,
      mode: this.mode,
      betAmount: this.betAmount,
      state: this.state,
      currentRound: this.currentRound,
      maxRounds: this.maxRounds,
      currentPlayerId: this.getCurrentPlayerId(),
      phase: this.phase,
      turnTime: this.turnTime,
      turnStartTime: this.turnStartTime,
      discardPile: this.discardPile.length > 0 ? this.discardPile[this.discardPile.length - 1] : null,
      discardCount: this.discardPile.length,
      deckRemaining: this.deck ? this.deck.remaining() : 0,
      players: {},
    };

    for (const [userId, player] of this.players) {
      state.players[userId] = {
        id: userId,
        nickname: player.nickname,
        avatar: player.avatar,
        cardCount: player.hand.length,
        ready: player.ready,
        connected: player.connected,
        isPifado: player.isPifado,
        hand: userId === forUserId ? player.hand : null, // Só mostrar mão do próprio jogador
      };
    }

    return state;
  }

  log(action, data) {
    this.gameLog.push({
      timestamp: Date.now(),
      action,
      ...data,
    });
  }

  getInfo() {
    return {
      id: this.id,
      name: this.name,
      mode: this.mode,
      betAmount: this.betAmount,
      maxPlayers: this.maxPlayers,
      currentPlayers: this.players.size,
      state: this.state,
      hasPassword: !!this.password,
    };
  }
}

module.exports = Room;