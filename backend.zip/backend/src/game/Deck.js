const crypto = require('crypto');

class Deck {
  constructor() {
    this.suits = ['hearts', 'spades', 'diamonds', 'clubs'];
    this.values = ['A', '2', '3', '4', '5', '6', '7', '8', '9', '10', 'J', 'Q', 'K'];
    this.cards = [];
    this.buildDeck();
    this.shuffle();
  }

  buildDeck() {
    this.cards = [];
    // Dois baralhos (104 cartas)
    for (let deck = 0; deck < 2; deck++) {
      for (const suit of this.suits) {
        for (const value of this.values) {
          this.cards.push({
            id: `${value}_${suit}_${deck}`,
            value,
            suit,
            deckIndex: deck,
          });
        }
      }
    }
  }

  // Fisher-Yates com seed criptográfico
  shuffle() {
    const array = this.cards;
    for (let i = array.length - 1; i > 0; i--) {
      const randomBytes = crypto.randomBytes(4);
      const randomInt = randomBytes.readUInt32BE(0);
      const j = randomInt % (i + 1);
      [array[i], array[j]] = [array[j], array[i]];
    }
  }

  draw() {
    if (this.cards.length === 0) return null;
    return this.cards.pop();
  }

  drawMultiple(count) {
    const drawn = [];
    for (let i = 0; i < count; i++) {
      const card = this.draw();
      if (card) drawn.push(card);
    }
    return drawn;
  }

  remaining() {
    return this.cards.length;
  }

  isEmpty() {
    return this.cards.length === 0;
  }
}

module.exports = Deck;