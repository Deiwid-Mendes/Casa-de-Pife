class Matchmaking {
  constructor() {
    // Filas por faixa de aposta
    this.queues = new Map();
    // free, 1, 2, 5, 10, 20
    const betLevels = [0, 1, 2, 5, 10, 20];
    betLevels.forEach(bet => {
      this.queues.set(bet, []);
    });
  }

  addToQueue(userId, nickname, avatar, socketId, betAmount) {
    // Remover de qualquer fila anterior
    this.removeFromAllQueues(userId);

    const queue = this.queues.get(betAmount);
    if (!queue) {
      throw new Error('Faixa de aposta inválida');
    }

    queue.push({
      userId,
      nickname,
      avatar,
      socketId,
      joinedAt: Date.now(),
    });

    return this.tryMatch(betAmount);
  }

  removeFromAllQueues(userId) {
    for (const [, queue] of this.queues) {
      const idx = queue.findIndex(p => p.userId === userId);
      if (idx !== -1) {
        queue.splice(idx, 1);
      }
    }
  }

  tryMatch(betAmount) {
    const queue = this.queues.get(betAmount);
    if (queue.length >= 2) {
      const player1 = queue.shift();
      const player2 = queue.shift();
      return { matched: true, players: [player1, player2], betAmount };
    }
    return { matched: false, position: queue.length, estimatedWait: queue.length * 15 };
  }

  getQueueSize(betAmount) {
    const queue = this.queues.get(betAmount);
    return queue ? queue.length : 0;
  }

  getQueueSizes() {
    const sizes = {};
    for (const [bet, queue] of this.queues) {
      sizes[bet] = queue.length;
    }
    return sizes;
  }
}

module.exports = Matchmaking;