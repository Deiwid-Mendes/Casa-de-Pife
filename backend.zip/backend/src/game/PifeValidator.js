class PifeValidator {
  static VALUE_ORDER = ['A', '2', '3', '4', '5', '6', '7', '8', '9', '10', 'J', 'Q', 'K'];

  static getValueIndex(value) {
    return this.VALUE_ORDER.indexOf(value);
  }

  static getNumericValue(value) {
    if (value === 'A') return 1;
    if (value === 'J') return 11;
    if (value === 'Q') return 12;
    if (value === 'K') return 13;
    return parseInt(value);
  }

  static getPenaltyValue(value) {
    if (value === 'A') return 1;
    if (['J', 'Q', 'K'].includes(value)) return 10;
    return parseInt(value);
  }

  // Verifica se 3 cartas formam uma trinca (mesmo valor, naipes diferentes)
  static isTriple(cards) {
    if (cards.length !== 3) return false;

    const sameValue = cards.every(c => c.value === cards[0].value);
    if (!sameValue) return false;

    // Naipes devem ser todos diferentes
    const suits = cards.map(c => c.suit);
    const uniqueSuits = new Set(suits);
    return uniqueSuits.size === 3;
  }

  // Verifica se 3 cartas formam uma sequência (mesmo naipe, valores consecutivos)
  static isSequence(cards) {
    if (cards.length !== 3) return false;

    const sameSuit = cards.every(c => c.suit === cards[0].suit);
    if (!sameSuit) return false;

    const indices = cards.map(c => this.getValueIndex(c.value)).sort((a, b) => a - b);

    // Sequência normal (ex: 4-5-6)
    if (indices[1] === indices[0] + 1 && indices[2] === indices[1] + 1) {
      return true;
    }

    // Sequência com Ás alto (Q-K-A)
    if (indices[0] === 0 && indices[1] === 11 && indices[2] === 12) {
      return true;
    }

    return false;
  }

  // Verifica se uma combinação de 3 cartas é válida
  static isValidCombination(cards) {
    return this.isTriple(cards) || this.isSequence(cards);
  }

  // Verifica se a mão completa (9 cartas) pode ser batida
  static canBat(hand) {
    if (hand.length !== 9) return false;

    // Tentar todas as combinações possíveis de 3 grupos de 3 cartas
    const permutations = this.getAllGroupings(hand);

    for (const grouping of permutations) {
      const allValid = grouping.every(group => this.isValidCombination(group));
      if (allValid) return grouping;
    }

    return false;
  }

  // Gera todas as formas possíveis de dividir 9 cartas em 3 grupos de 3
  static getAllGroupings(cards) {
    const groupings = [];
    const indices = Array.from({ length: 9 }, (_, i) => i);

    // Gerar todas combinações de 3 para o primeiro grupo
    const combos3 = this.combinations(indices, 3);

    for (const first of combos3) {
      const remaining1 = indices.filter(i => !first.includes(i));

      // Gerar combinações de 3 para o segundo grupo (do restante)
      const combos3_2 = this.combinations(remaining1, 3);

      for (const second of combos3_2) {
        const third = remaining1.filter(i => !second.includes(i));

        // Evitar duplicatas (normalizar ordem dos grupos)
        const firstMin = Math.min(...first);
        const secondMin = Math.min(...second);
        if (secondMin < firstMin) continue;

        const thirdMin = Math.min(...third);
        if (thirdMin < secondMin) continue;

        groupings.push([
          first.map(i => cards[i]),
          second.map(i => cards[i]),
          third.map(i => cards[i]),
        ]);
      }
    }

    return groupings;
  }

  // Gera combinações C(n, k)
  static combinations(array, k) {
    const results = [];

    function combine(start, current) {
      if (current.length === k) {
        results.push([...current]);
        return;
      }
      for (let i = start; i < array.length; i++) {
        current.push(array[i]);
        combine(i + 1, current);
        current.pop();
      }
    }

    combine(0, []);
    return results;
  }

  // Verifica se o jogador está "pifado" (falta 1 carta para bater)
  static isPifado(hand) {
    if (hand.length !== 9) return false;

    // Para cada carta na mão, testar remover e substituir por qualquer carta possível
    const allPossibleCards = this.generateAllPossibleCards();

    for (let removeIdx = 0; removeIdx < hand.length; removeIdx++) {
      const reducedHand = hand.filter((_, i) => i !== removeIdx);

      for (const newCard of allPossibleCards) {
        const testHand = [...reducedHand, newCard];
        if (this.canBat(testHand)) {
          return true;
        }
      }
    }

    return false;
  }

  // Verifica quais cartas fariam o jogador bater (quando tem 9 cartas e compra 1)
  static getWinningCards(hand) {
    if (hand.length !== 9) return [];

    const winningCards = [];
    const allPossibleCards = this.generateAllPossibleCards();

    for (const card of allPossibleCards) {
      // Testar adicionar essa carta e remover cada uma das 10
      const testHand = [...hand, card];

      for (let removeIdx = 0; removeIdx < testHand.length; removeIdx++) {
        const finalHand = testHand.filter((_, i) => i !== removeIdx);
        if (this.canBat(finalHand)) {
          winningCards.push(card);
          break;
        }
      }
    }

    return winningCards;
  }

  // Verifica se adicionar uma carta específica à mão permite bater
  static canBatWithCard(hand, newCard) {
    if (hand.length !== 9) return false;

    const testHand = [...hand, newCard];

    // Testar descartar cada carta da mão de 10
    for (let i = 0; i < testHand.length; i++) {
      const finalHand = testHand.filter((_, idx) => idx !== i);
      const result = this.canBat(finalHand);
      if (result) return { discardIndex: i, groups: result };
    }

    return false;
  }

  // Gera todas as cartas possíveis (para verificação de pifado)
  static generateAllPossibleCards() {
    const suits = ['hearts', 'spades', 'diamonds', 'clubs'];
    const values = ['A', '2', '3', '4', '5', '6', '7', '8', '9', '10', 'J', 'Q', 'K'];
    const cards = [];

    for (const suit of suits) {
      for (const value of values) {
        cards.push({ value, suit, id: `test_${value}_${suit}` });
      }
    }

    return cards;
  }

  // Calcular pontos de penalidade de cartas soltas na mão
  static calculatePenalty(hand) {
    // Encontrar melhor agrupamento parcial e somar valor das cartas soltas
    let minPenalty = hand.reduce((sum, card) => sum + this.getPenaltyValue(card.value), 0);

    // Tentar encontrar combinações válidas e excluir do penalty
    const usedIndices = new Set();

    // Encontrar todas trincas possíveis
    for (let i = 0; i < hand.length; i++) {
      for (let j = i + 1; j < hand.length; j++) {
        for (let k = j + 1; k < hand.length; k++) {
          if (!usedIndices.has(i) && !usedIndices.has(j) && !usedIndices.has(k)) {
            if (this.isValidCombination([hand[i], hand[j], hand[k]])) {
              // Calcular penalty sem essas cartas
              const remaining = hand.filter((_, idx) => idx !== i && idx !== j && idx !== k);
              const penalty = remaining.reduce((sum, card) => sum + this.getPenaltyValue(card.value), 0);
              if (penalty < minPenalty) {
                minPenalty = penalty;
              }
            }
          }
        }
      }
    }

    return minPenalty;
  }
}

module.exports = PifeValidator;