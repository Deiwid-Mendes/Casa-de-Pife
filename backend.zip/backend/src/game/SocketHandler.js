const jwt = require('jsonwebtoken');
const GameEngine = require('./GameEngine');
const Matchmaking = require('./Matchmaking');
const User = require('../models/User');

const gameEngine = new GameEngine();
const matchmaking = new Matchmaking();

// Map de socketId -> userId
const socketUsers = new Map();
// Map de userId -> socketId
const userSockets = new Map();
// Map de userId -> roomId
const userRooms = new Map();

function setupSocketHandlers(io) {
  // Middleware de autenticação
  io.use(async (socket, next) => {
    try {
      const token = socket.handshake.auth.token;
      if (!token) {
        return next(new Error('Autenticação necessária'));
      }

      const decoded = jwt.verify(token, process.env.JWT_SECRET);
      const user = await User.findById(decoded.userId);

      if (!user) {
        return next(new Error('Usuário não encontrado'));
      }

      socket.userId = user.id;
      socket.nickname = user.nickname;
      socket.avatar = user.avatar;
      socket.userCoins = parseFloat(user.coins);

      next();
    } catch (error) {
      next(new Error('Token inválido'));
    }
  });

  io.on('connection', (socket) => {
    console.log(`🟢 ${socket.nickname} conectou (${socket.id})`);

    socketUsers.set(socket.id, socket.userId);
    userSockets.set(socket.userId, socket.id);

    // Enviar salas ativas
    socket.emit('rooms:list', gameEngine.listRooms());
    socket.emit('matchmaking:queue_sizes', matchmaking.getQueueSizes());

    // ================ MATCHMAKING ================

    socket.on('matchmaking:join', async ({ betAmount }) => {
      try {
        betAmount = parseFloat(betAmount);

        // Verificar saldo
        if (betAmount > 0) {
          const coins = await User.getCoins(socket.userId);
          if (parseFloat(coins) < betAmount) {
            return socket.emit('error', { message: 'Saldo insuficiente' });
          }
        }

        const result = matchmaking.addToQueue(
          socket.userId, socket.nickname, socket.avatar, socket.id, betAmount
        );

        if (result.matched) {
          // Match encontrado! Criar sala
          const room = gameEngine.createRoom({
            mode: betAmount > 0 ? 'matchmaking' : 'free',
            betAmount,
            maxPlayers: 2,
            maxRounds: 1,
            turnTime: 45,
          });

          for (const player of result.players) {
            room.addPlayer(player.userId, player.nickname, player.avatar, player.socketId);

            // Debitar aposta
            if (betAmount > 0) {
              await gameEngine.debitBet(player.userId, betAmount);
            }

            userRooms.set(player.userId, room.id);
            const playerSocket = io.sockets.sockets.get(player.socketId);
            if (playerSocket) {
              playerSocket.join(room.id);
            }
          }

          io.to(room.id).emit('matchmaking:found', {
            roomId: room.id,
            players: result.players.map(p => ({
              id: p.userId,
              nickname: p.nickname,
              avatar: p.avatar,
            })),
            betAmount,
          });

          // Auto-ready para matchmaking
          for (const player of result.players) {
            room.setReady(player.userId);
          }

          // Iniciar jogo automaticamente
          setTimeout(() => {
            try {
              const gameState = room.startGame();
              // Enviar estado para cada jogador (com suas cartas)
              for (const [userId] of room.players) {
                const playerSocketId = userSockets.get(userId);
                if (playerSocketId) {
                  io.to(playerSocketId).emit('game:state', room.getGameState(userId));
                }
              }
              startTurnTimer(io, room);
            } catch (e) {
              console.error('Erro ao iniciar jogo:', e);
            }
          }, 3000);

        } else {
          socket.emit('matchmaking:waiting', {
            position: result.position,
            estimatedWait: result.estimatedWait,
          });
        }

        // Broadcast queue sizes
        io.emit('matchmaking:queue_sizes', matchmaking.getQueueSizes());
      } catch (error) {
        socket.emit('error', { message: error.message });
      }
    });

    socket.on('matchmaking:leave', () => {
      matchmaking.removeFromAllQueues(socket.userId);
      socket.emit('matchmaking:left');
      io.emit('matchmaking:queue_sizes', matchmaking.getQueueSizes());
    });

    // ================ SALA PRIVADA ================

    socket.on('room:create', async ({ name, betAmount, maxPlayers, maxRounds, turnTime, password }) => {
      try {
        betAmount = parseFloat(betAmount || 0);

        if (betAmount > 0) {
          const coins = await User.getCoins(socket.userId);
          if (parseFloat(coins) < betAmount) {
            return socket.emit('error', { message: 'Saldo insuficiente' });
          }
        }

        const room = gameEngine.createRoom({
          name,
          mode: betAmount > 0 ? 'private' : 'free',
          betAmount,
          maxPlayers: maxPlayers || 2,
          maxRounds: maxRounds || 1,
          turnTime: turnTime || 45,
          password,
          creatorId: socket.userId,
        });

        room.addPlayer(socket.userId, socket.nickname, socket.avatar, socket.id);

        if (betAmount > 0) {
          await gameEngine.debitBet(socket.userId, betAmount);
        }

        userRooms.set(socket.userId, room.id);
        socket.join(room.id);

        socket.emit('room:created', {
          roomId: room.id,
          password,
          info: room.getInfo(),
        });

        io.emit('rooms:list', gameEngine.listRooms());
      } catch (error) {
        socket.emit('error', { message: error.message });
      }
    });

    socket.on('room:join', async ({ roomId, password }) => {
      try {
        const room = gameEngine.getRoom(roomId);
        if (!room) {
          return socket.emit('error', { message: 'Sala não encontrada' });
        }

        if (room.password && room.password !== password) {
          return socket.emit('error', { message: 'Senha incorreta' });
        }

        if (room.betAmount > 0) {
          const coins = await User.getCoins(socket.userId);
          if (parseFloat(coins) < room.betAmount) {
            return socket.emit('error', { message: 'Saldo insuficiente' });
          }
          await gameEngine.debitBet(socket.userId, room.betAmount);
        }

        room.addPlayer(socket.userId, socket.nickname, socket.avatar, socket.id);
        userRooms.set(socket.userId, room.id);
        socket.join(roomId);

        io.to(roomId).emit('room:player_joined', {
          player: {
            id: socket.userId,
            nickname: socket.nickname,
            avatar: socket.avatar,
          },
          info: room.getInfo(),
        });

        socket.emit('room:joined', {
          roomId: room.id,
          info: room.getInfo(),
          players: Array.from(room.players.values()).map(p => ({
            id: p.id,
            nickname: p.nickname,
            avatar: p.avatar,
            ready: p.ready,
          })),
        });

        io.emit('rooms:list', gameEngine.listRooms());
      } catch (error) {
        socket.emit('error', { message: error.message });
      }
    });

    socket.on('room:ready', () => {
      const roomId = userRooms.get(socket.userId);
      if (!roomId) return;

      const room = gameEngine.getRoom(roomId);
      if (!room) return;

      room.setReady(socket.userId);
      io.to(roomId).emit('room:player_ready', { userId: socket.userId });

      // Verificar se todos estão prontos
      if (room.allReady()) {
        try {
          const gameState = room.startGame();
          for (const [userId] of room.players) {
            const playerSocketId = userSockets.get(userId);
            if (playerSocketId) {
              io.to(playerSocketId).emit('game:started', room.getGameState(userId));
            }
          }
          startTurnTimer(io, room);
        } catch (e) {
          io.to(roomId).emit('error', { message: e.message });
        }
      }
    });

    // ================ GAMEPLAY ================

    socket.on('game:buy_deck', () => {
      try {
        const roomId = userRooms.get(socket.userId);
        const room = gameEngine.getRoom(roomId);
        if (!room) return socket.emit('error', { message: 'Sala não encontrada' });

        const result = room.buyFromDeck(socket.userId);

        // Enviar carta comprada só para o jogador
        socket.emit('game:card_bought', {
          source: 'deck',
          card: result.card,
          canBat: result.canBat,
          deckRemaining: result.deckRemaining,
        });

        // Notificar outros que o jogador comprou do monte
        socket.to(roomId).emit('game:opponent_bought', {
          userId: socket.userId,
          source: 'deck',
          deckRemaining: result.deckRemaining,
        });

        resetTurnTimer(io, room);
      } catch (error) {
        socket.emit('error', { message: error.message });
      }
    });

    socket.on('game:buy_discard', () => {
      try {
        const roomId = userRooms.get(socket.userId);
        const room = gameEngine.getRoom(roomId);
        if (!room) return socket.emit('error', { message: 'Sala não encontrada' });

        const result = room.buyFromDiscard(socket.userId);

        socket.emit('game:card_bought', {
          source: 'discard',
          card: result.card,
          canBat: result.canBat,
          topDiscard: result.topDiscard,
        });

        socket.to(roomId).emit('game:opponent_bought', {
          userId: socket.userId,
          source: 'discard',
          topDiscard: result.topDiscard,
        });

        resetTurnTimer(io, room);
      } catch (error) {
        socket.emit('error', { message: error.message });
      }
    });

    socket.on('game:discard', ({ cardId }) => {
      try {
        const roomId = userRooms.get(socket.userId);
        const room = gameEngine.getRoom(roomId);
        if (!room) return socket.emit('error', { message: 'Sala não encontrada' });

        const result = room.discard(socket.userId, cardId);

        // Notificar todos do descarte
        io.to(roomId).emit('game:card_discarded', {
          userId: socket.userId,
          card: result.discardedCard,
          deckRemaining: result.deckRemaining,
        });

        // Verificar interceptores (jogadores pifados que podem bater)
        if (result.interceptors.length > 0) {
          for (const interceptor of result.interceptors) {
            const intSocketId = userSockets.get(interceptor.playerId);
            if (intSocketId) {
              io.to(intSocketId).emit('game:can_intercept', {
                card: result.discardedCard,
                timeout: 5000, // 5 segundos para decidir
              });
            }
          }
        }

        // Monte vazio - empate
        if (result.deckEmpty) {
          const drawResult = room.handleEmptyDeck();
          handleGameEnd(io, room, drawResult);
          return;
        }

        // Enviar estado atualizado
        for (const [userId] of room.players) {
          const playerSocketId = userSockets.get(userId);
          if (playerSocketId) {
            io.to(playerSocketId).emit('game:state', room.getGameState(userId));
          }
        }

        startTurnTimer(io, room);
      } catch (error) {
        socket.emit('error', { message: error.message });
      }
    });

    socket.on('game:bat', () => {
      try {
        const roomId = userRooms.get(socket.userId);
        const room = gameEngine.getRoom(roomId);
        if (!room) return socket.emit('error', { message: 'Sala não encontrada' });

        const results = room.bat(socket.userId);
        handleGameEnd(io, room, results);
      } catch (error) {
        socket.emit('error', { message: error.message });
      }
    });

    socket.on('game:intercept_bat', () => {
      try {
        const roomId = userRooms.get(socket.userId);
        const room = gameEngine.getRoom(roomId);
        if (!room) return socket.emit('error', { message: 'Sala não encontrada' });

        const results = room.interceptBat(socket.userId);
        handleGameEnd(io, room, results);
      } catch (error) {
        socket.emit('error', { message: error.message });
      }
    });

    // ================ CHAT ================

    socket.on('chat:emoji', ({ emoji }) => {
      const roomId = userRooms.get(socket.userId);
      if (!roomId) return;

      const validEmojis = ['👍', '👎', '😂', '😡', '🤔', '😎', '🎉', '💀', '🔥', '❤️', '😢', '🤣'];
      if (!validEmojis.includes(emoji)) return;

      io.to(roomId).emit('chat:emoji', {
        userId: socket.userId,
        nickname: socket.nickname,
        emoji,
      });
    });

    // ================ DESCONEXÃO ================

    socket.on('disconnect', async () => {
      console.log(`🔴 ${socket.nickname} desconectou`);

      matchmaking.removeFromAllQueues(socket.userId);

      const roomId = userRooms.get(socket.userId);
      if (roomId) {
        const room = gameEngine.getRoom(roomId);
        if (room) {
          const player = room.players.get(socket.userId);
          if (player) {
            player.connected = false;
          }

          if (room.state === 'waiting') {
            room.removePlayer(socket.userId);
            if (room.betAmount > 0) {
              await gameEngine.refundBet(socket.userId, room.betAmount);
            }
            if (room.players.size === 0) {
              gameEngine.deleteRoom(roomId);
            }
          } else if (room.state === 'playing') {
            // Dar tempo para reconectar
            setTimeout(async () => {
              const currentPlayer = room.players.get(socket.userId);
              if (currentPlayer && !currentPlayer.connected) {
                // Jogador não reconectou - perde por desistência
                const otherPlayers = Array.from(room.players.keys()).filter(id => id !== socket.userId);
                if (otherPlayers.length > 0) {
                  const results = room.endRound(otherPlayers[0], []);
                  results.disconnection = true;
                  await handleGameEnd(io, room, results);
                }
              }
            }, 30000); // 30 segundos para reconectar
          }

          io.to(roomId).emit('room:player_disconnected', { userId: socket.userId });
        }
        userRooms.delete(socket.userId);
      }

      socketUsers.delete(socket.id);
      userSockets.delete(socket.userId);

      io.emit('matchmaking:queue_sizes', matchmaking.getQueueSizes());
    });

    // Reconexão
    socket.on('game:reconnect', () => {
      const roomId = userRooms.get(socket.userId);
      if (!roomId) return;

      const room = gameEngine.getRoom(roomId);
      if (!room) return;

      const player = room.players.get(socket.userId);
      if (player) {
        player.connected = true;
        player.socketId = socket.id;
        socket.join(roomId);

        socket.emit('game:state', room.getGameState(socket.userId));

        io.to(roomId).emit('room:player_reconnected', { userId: socket.userId });
      }
    });
  });

  // Timer de turno
  function startTurnTimer(io, room) {
    if (room.turnTimer) {
      clearTimeout(room.turnTimer);
    }

    room.turnTimer = setTimeout(() => {
      if (room.state !== 'playing') return;

      const currentPlayerId = room.getCurrentPlayerId();
      const result = room.autoPlay(currentPlayerId);

      if (result) {
        // Notificar auto-play
        io.to(room.id).emit('game:auto_play', {
          userId: currentPlayerId,
          result,
        });

        // Enviar estado atualizado
        for (const [userId] of room.players) {
          const playerSocketId = userSockets.get(userId);
          if (playerSocketId) {
            io.to(playerSocketId).emit('game:state', room.getGameState(userId));
          }
        }

        startTurnTimer(io, room);
      }
    }, room.turnTime * 1000);
  }

  function resetTurnTimer(io, room) {
    // Não reiniciar timer durante a fase de descarte (jogador ainda está jogando)
  }

  async function handleGameEnd(io, room, results) {
    try {
      // Processar moedas e histórico
      await gameEngine.processGameEnd(room, results);

      // Enviar resultado para todos
      io.to(room.id).emit('game:ended', results);

      // Atualizar saldo de cada jogador
      for (const [userId] of room.players) {
        const coins = await User.getCoins(userId);
        const playerSocketId = userSockets.get(userId);
        if (playerSocketId) {
          io.to(playerSocketId).emit('user:balance_updated', {
            coins: parseFloat(coins),
          });
        }
      }

      // Limpar room após delay
      setTimeout(() => {
        for (const [userId] of room.players) {
          userRooms.delete(userId);
        }
        gameEngine.deleteRoom(room.id);
      }, 30000);
    } catch (error) {
      console.error('Erro ao finalizar jogo:', error);
    }
  }
}

module.exports = setupSocketHandlers;