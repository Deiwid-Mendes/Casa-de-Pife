const Room = require('./Room');
const User = require('../models/User');
const Transaction = require('../models/Transaction');
const GameHistory = require('../models/GameHistory');

class GameEngine {
  constructor() {
    this.rooms = new Map();
  }

  createRoom(options) {
    const room = new Room(options);
    this.rooms.set(room.id, room);
    return room;
  }

  getRoom(roomId) {
    return this.rooms.get(roomId);
  }

  deleteRoom(roomId) {
    this.rooms.delete(roomId);
  }

  listRooms(mode = null) {
    const rooms = [];
    for (const [, room] of this.rooms) {
      if (!mode || room.mode === mode) {
        if (room.state === 'waiting') {
          rooms.push(room.getInfo());
        }
      }
    }
    return rooms;
  }

  async processGameEnd(room, results) {
    try {
      // Salvar histórico
      const gameRecord = await GameHistory.create({
        roomId: room.id,
        mode: room.mode,
        betAmount: room.betAmount,
        potAmount: results.potAmount || 0,
        rakeAmount: results.rakeAmount || 0,
        winnerId: results.winnerId,
        players: Object.keys(results.players).map(id => ({
          id,
          nickname: results.players[id].nickname,
        })),
        gameLog: room.gameLog,
        durationSeconds: results.duration || 0,
        startedAt: room.startedAt,
      });

      // Processar moedas para cada jogador
      for (const [userId, playerResult] of Object.entries(results.players)) {
        // Salvar participação
        await GameHistory.addPlayer({
          gameId: gameRecord.id,
          userId,
          finalHand: playerResult.hand,
          isWinner: playerResult.isWinner,
          coinsChange: playerResult.coinsChange,
          penaltyPoints: playerResult.penaltyPoints,
        });

        // Atualizar estatísticas
        await User.updateStats(userId, playerResult.isWinner);

        // Processar moedas (em modo com aposta)
        if (room.mode !== 'free' && !results.refund) {
          if (playerResult.isWinner) {
            // Vencedor recebe o pote menos rake
            await User.updateCoins(userId, results.winAmount);
            await Transaction.create({
              userId,
              type: 'win',
              amount: results.winAmount,
              status: 'completed',
              description: `Vitória na ${room.name} - Pote: ${results.potAmount}`,
            });
          }
          // A aposta já foi debitada ao entrar na partida
        }
      }

      // Registrar rake
      if (results.rakeAmount > 0) {
        await Transaction.create({
          userId: results.winnerId,
          type: 'rake',
          amount: results.rakeAmount,
          status: 'completed',
          description: `Rake da sala ${room.id}`,
        });
      }

      return gameRecord;
    } catch (error) {
      console.error('Erro ao processar fim de jogo:', error);
    }
  }

  async debitBet(userId, betAmount) {
    const coins = await User.getCoins(userId);
    if (parseFloat(coins) < betAmount) {
      throw new Error('Saldo insuficiente');
    }

    await User.updateCoins(userId, -betAmount);
    await Transaction.create({
      userId,
      type: 'bet',
      amount: betAmount,
      status: 'completed',
      description: `Aposta em partida`,
    });
  }

  async refundBet(userId, betAmount) {
    await User.updateCoins(userId, betAmount);
    await Transaction.create({
      userId,
      type: 'refund',
      amount: betAmount,
      status: 'completed',
      description: `Devolução de aposta`,
    });
  }
}

module.exports = GameEngine;