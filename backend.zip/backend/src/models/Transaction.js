const { pool } = require('../config/database');

class Transaction {
  static async create({ userId, type, amount, status = 'pending', paymentMethod, description }) {
    const result = await pool.query(
      `INSERT INTO transactions (user_id, type, amount, status, payment_method, description)
       VALUES ($1, $2, $3, $4, $5, $6)
       RETURNING *`,
      [userId, type, amount, status, paymentMethod, description]
    );
    return result.rows[0];
  }

  static async updateStatus(id, status) {
    const result = await pool.query(
      'UPDATE transactions SET status = $1 WHERE id = $2 RETURNING *',
      [status, id]
    );
    return result.rows[0];
  }

  static async getByUser(userId, limit = 50) {
    const result = await pool.query(
      'SELECT * FROM transactions WHERE user_id = $1 ORDER BY created_at DESC LIMIT $2',
      [userId, limit]
    );
    return result.rows;
  }
}

module.exports = Transaction;