const { pool } = require('../config/database');
const bcrypt = require('bcryptjs');
const { v4: uuidv4 } = require('uuid');

class User {
  static async create({ nickname, email, password, birthDate }) {
    const passwordHash = await bcrypt.hash(password, 12);
    const emailToken = uuidv4();

    const result = await pool.query(
      `INSERT INTO users (nickname, email, password_hash, birth_date, email_token)
       VALUES ($1, $2, $3, $4, $5)
       RETURNING id, nickname, email, player_id, coins, avatar, created_at`,
      [nickname, email, passwordHash, birthDate, emailToken]
    );

    return { user: result.rows[0], emailToken };
  }

  static async findByEmail(email) {
    const result = await pool.query('SELECT * FROM users WHERE email = $1', [email]);
    return result.rows[0];
  }

  static async findByNickname(nickname) {
    const result = await pool.query('SELECT * FROM users WHERE nickname = $1', [nickname]);
    return result.rows[0];
  }

  static async findById(id) {
    const result = await pool.query(
      'SELECT id, nickname, email, coins, avatar, player_id, total_games, total_wins, total_losses, created_at FROM users WHERE id = $1',
      [id]
    );
    return result.rows[0];
  }

  static async verifyEmail(token) {
    const result = await pool.query(
      `UPDATE users SET email_verified = TRUE, email_token = NULL
       WHERE email_token = $1
       RETURNING id, nickname, email`,
      [token]
    );
    return result.rows[0];
  }

  static async updateCoins(userId, amount) {
    const result = await pool.query(
      `UPDATE users SET coins = coins + $1, updated_at = CURRENT_TIMESTAMP
       WHERE id = $2
       RETURNING id, coins`,
      [amount, userId]
    );
    return result.rows[0];
  }

  static async getCoins(userId) {
    const result = await pool.query('SELECT coins FROM users WHERE id = $1', [userId]);
    return result.rows[0]?.coins || 0;
  }

  static async updateStats(userId, isWinner) {
    if (isWinner) {
      await pool.query(
        'UPDATE users SET total_games = total_games + 1, total_wins = total_wins + 1 WHERE id = $1',
        [userId]
      );
    } else {
      await pool.query(
        'UPDATE users SET total_games = total_games + 1, total_losses = total_losses + 1 WHERE id = $1',
        [userId]
      );
    }
  }

  static async updateAvatar(userId, avatar) {
    await pool.query('UPDATE users SET avatar = $1 WHERE id = $2', [avatar, userId]);
  }

  static async comparePassword(password, hash) {
    return bcrypt.compare(password, hash);
  }
}

module.exports = User;