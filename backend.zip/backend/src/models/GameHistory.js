const { pool } = require('../config/database');

class GameHistory {
  static async create({ roomId, mode, betAmount, potAmount, rakeAmount, winnerId, players, gameLog, durationSeconds, startedAt }) {
    const result = await pool.query(
      `INSERT INTO game_history (room_id, mode, bet_amount, pot_amount, rake_amount, winner_id, players, game_log, duration_seconds, started_at)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10)
       RETURNING *`,
      [roomId, mode, betAmount, potAmount, rakeAmount, winnerId, JSON.stringify(players), JSON.stringify(gameLog), durationSeconds, startedAt]
    );
    return result.rows[0];
  }

  static async getByUser(userId, limit = 20) {
    const result = await pool.query(
      `SELECT gh.*, gp.is_winner, gp.coins_change
       FROM game_history gh
       JOIN game_players gp ON gp.game_id = gh.id
       WHERE gp.user_id = $1
       ORDER BY gh.finished_at DESC
       LIMIT $2`,
      [userId, limit]
    );
    return result.rows;
  }

  static async addPlayer({ gameId, userId, finalHand, isWinner, coinsChange, penaltyPoints }) {
    await pool.query(
      `INSERT INTO game_players (game_id, user_id, final_hand, is_winner, coins_change, penalty_points)
       VALUES ($1, $2, $3, $4, $5, $6)`,
      [gameId, userId, JSON.stringify(finalHand), isWinner, coinsChange, penaltyPoints]
    );
  }
}

module.exports = GameHistory;