const { Pool } = require('pg');
require('dotenv').config();

const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  max: 20,
  idleTimeoutMillis: 30000,
  connectionTimeoutMillis: 2000,
});

pool.on('connect', () => {
  console.log('📦 Conectado ao PostgreSQL');
});

pool.on('error', (err) => {
  console.error('❌ Erro no PostgreSQL:', err);
});

// Inicializar tabelas
const initDatabase = async () => {
  const fs = require('fs');
  const path = require('path');
  try {
    const schema = fs.readFileSync(
      path.join(__dirname, '../../database/schema.sql'),
      'utf8'
    );
    await pool.query(schema);
    console.log('✅ Tabelas do banco inicializadas');
  } catch (error) {
    console.error('❌ Erro ao inicializar banco:', error.message);
  }
};

module.exports = { pool, initDatabase };